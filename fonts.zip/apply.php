<?php 
	require_once 'db/db.php'; 
	if (isset($_POST['ok']))
	 {
		// $surname = $_POST['surname'];
		// $othername = $_POST['othername'];
		// $form_type = $_POST['form-type'];
		$email = $_POST['email'];
		$phone = $_POST['phone'];
		$fname = $_POST['fname'];
		$matric_no = $_POST['matric_no'];
		$password = $_POST['password'];
		$cpassword = $_POST['cpassword'];
		$dept = $_POST['dept'];
		$level = $_POST['level'];
		$error = array();
		$stmt = $db->prepare("SELECT NULL FROM students matric_no =:matric_no");
		$stmt->execute(array('matric_no' => $matric_no));
		if ($stmt->rowCount() >= 1) 
		{
			$error[] = 'Matric number has already been used';
		}
		if (strlen($matric_no) < 11) 
		{
			$error[] = 'Matric number is too short, it should be 11 at least 11';
		}
		if (strlen($fname) < 10) 
		{
			$error[] = 'Full name should be at least 10 characters';
		}
		if (strlen($password) < 5) 
		{
			$error[] = 'Password should not exceed 5 characters';
		}
		if (strlen($cpassword) < 5) 
		{
			$error[] = 'Retype password should be at least 5 characters';
		}
		if ($password != $cpassword) 
		{
			$error[] = 'Password did not match retype password';
		}
		if (isset($_FILES['upl'])) 
		{
			$files = $_FILES['upl'];
			$allowed = array('jpg','png','jpeg');
			$name = $_FILES['upl']['name'];
			$n = pathinfo($_FILES['upl']['name'], PATHINFO_EXTENSION);
			if ($name == "") 
			{
				$error[] = 'Your image is required';
			}else{
				if (!in_array($n, $allowed)) 
				{
					$error[] = 'Only jpeg png, and jpg format is allowed';
				}else{
					if ($files['size']  > 1024 * 1024 * 1) 
					{
						$error[] = 'Maximum file upload is 1MB';
					}
				}
			}
			$folder = '../images/';
			$t = uniqid().$name;
			$destination = $folder.$t;
		}
		if (count($error) == 0) 
		{
			if (move_uploaded_file($_FILES['upl']['tmp_name'], $destination)) 
			{
				$stmt = $db->prepare("INSERT INTO students (upl,matric_no,fname,password,email,phone,dept,level,semester,add_date)VALUES(:upl,:matric_no,:fname,:password,:email,:phone,:dept,:level,:semester,:add_date)");
				$stmt->execute(array(
					'upl' => $t,
					'matric_no' => $matric_no,
					'fname' => $fname,
					'password' => $password,
					'email' => $email,
					'phone' => $phone,
					'dept' => $dept,
					'level' => $level,
					'semester' => 1,
					'add_date' => date('d M, Y')
					));
				set_flash('Your successfully registered, try to login','info');
				header('location:login.php');
				exit();
			}
			$msg = count($error).' error(s) occur while Register. Please check the error below!';
		}else{
			foreach ($error as $value) 
			{
				$msg.='<p>'.$value.'</p>';
			}
			set_flash($msg,'danger');
		}
		$stmt->closeCursor();		
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Registration &dash; The Federal Polytechnic Ede, Osun State</title>
	<?php require_once 'libs/css.php'; ?>
</head>
<body>
<?php require_once 'libs/menu.php'; ?>

	<section id="section-body">
		<div class="container">
			<div class="row">
					<form class="form-group" method="post" role="form" enctype="multipart/form-data">
					<div class="col-lg-7 col-sm-offset-1 col-md-7 col-sm-12 col-xs-12">
						<div class="profile-top">
							<?php flash(); ?>
							<div class="solid-form"><span>Register</span></div>		
								<div class="row">
									<div class="col-sm-6">
										<div class="form-group">
											<label>Matric Number <span class="error-text">required</span></label>
											<div class="input-group">
												<span class="input-group-addon">
													<i class="fa fa-user"></i>
												</span>
												<input type="text" maxlength="15" value="<?php echo @$_POST['matric_no']; ?>" name="matric_no" class="form-control" required="" placeholder="Matric Number">
											</div>
										</div>		
									</div>

									<div class="col-sm-6">
										<div class="form-group">
											<label for="surname">Full Name <span class="error-text">(required)</span></label>
											<div class="input-group">
												<span class="input-group-addon">
													<i class="fa fa-user"></i>
												</span>
												<input type="text" name="fname" maxlength="30" value="<?php echo@$_POST['fname']; ?>" class="form-control" required="" placeholder="Full Name">
											</div>
										</div>
									</div>

									<div class="col-sm-6">
										<div class="form-group">
											<label>Password <span class="error-text">(required)</span></label>
											<div class="input-group">
												<span class="input-group-addon">
													<i class="fa fa-key"></i>
												</span>
												<input type="password" name="password" maxlength="15" value="<?php echo@$_POST['password']; ?>" class="form-control" required="" placeholder="Password">
											</div>
										</div>
									</div>

									<div class="col-sm-6">
										<div class="form-group">
										<label>Retype Password <span class="error-text">Required</span></label>
										<div class="input-group">
											<span class="input-group-addon">
												<i class="fa fa-key"></i>
											</span>
											<input type="password" name="cpassword" value="<?php echo@$_POST['cpassword']; ?>" maxlength="15" class="form-control" required="" placeholder="Retype password">
										</div>
									</div>

									</div>

									<div class="col-sm-6">
										<div class="form-group">
										<label for="email">Email Address <span class="error-text">(required)</span></label>
										<div class="input-group">
											<span class="input-group-addon">
												<i class="fa fa-envelope-o"></i>
											</span>
											<input type="email" name="email" maxlength="100" value="<?php echo @$_POST['email']; ?>" class="form-control" required="" placeholder="Email Address">
										</div>
									</div>
									</div>

									<div class="col-sm-6">
										<div class="form-group">
										<label for="phone-number">Phone Number <span class="error-text">(required)</span></label>
										<div class="input-group">
											<span class="input-group-addon">
												<i class="fa fa-phone"></i>
											</span>
											<input type="text" name="phone" value="<?php echo@$_POST['phone']; ?>" maxlength="11" class="form-control" required="" placeholder="Phone Number">
										</div>
									</div>
									</div>

									<div class="col-sm-6">
										<div class="form-group">
											<label>Department <span class="error-text">(required)</span></label>
											<div class="input-group">
												<span class="input-group-addon">
													<i class="fa fa-university"></i>
												</span>
												<select class="form-control form-control-select custom-select" required="" name="dept">
													<option>Computer Science</option>
												</select>
											</div>
										</div>
									</div>

									<div class="col-sm-6">
										<div class="form-group">
									<label>Level <span class="error-text">required</span></label>
									<div class="input-group">
										<span class="input-group-addon">
											<i class="fa fa-university"></i>
										</span>
										<select class="form-control form-control-select custom-select" name="level" required="">
											<option>100L</option>
											<option>200L FT</option>
											<option>300L(Sci. Opt.)</option>
											<option>300L(Eng. Opt) </option>
											<option>400L FT</option>
											<option>500L(Sci. Opt.)</option>
											<option>200L(Eng. Opt.)</option>
										</select>
									</div>
								</div>
									</div>
								</div>
								<div class="form-group">
									<div class="pull-left">
										<input type="submit" name="ok" class="btn btn-primary" value="Submit">
									</div>
								</div>
							</div>
							
					</div>
				</div>
				<div class="col-sm-4">
					<div class="profile-top">
						<label>Attach Your Image <span class="error-text">(Here)</span></label>
            			<div id="image-preview" class="w-100" style="height: 200px; background-image: url('image/5a1fdc70eee14.avatar5.png');">
                       <label for="image-upload" id="image-label">Choose File</label>
                       <input type="file" name="upl" accept="image/*" id="image-upload">
                   </div>
					</div>
				</div>
			</form>
			</div>
		</div>
	</section>

<?php require_once 'libs/js.php'; ?>
</body>
</html>
