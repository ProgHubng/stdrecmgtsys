<?php 
	$page_title = "Assign Course For Lecturer";
	require_once '../core/all.php';
	if (!is_admin_login()) {
		header("location:index.php");
		exit();
	}
	if (isset($_POST['ok'])){
		$course = $_POST['course'];
		$semester = $_POST['semester'];
		$session = $_POST['session'];
		$staff_id = $_POST['by'];
		$schedule = $_POST['schedule'];

		$error = array();

		$errors = array('departmental course'=>$course,'semester'=>$semester,'session'=>$session,'Lecturer'=>$staff_id);
		
		foreach ($errors as $key => $value) {
			if ($value == 0){
				$error[] = ucwords($key)." field are required";
			}
		}

		$sql = $db->query("SELECT * FROM course WHERE id ='$course'");
		$rs = $sql->fetch(PDO::FETCH_ASSOC);

        $level = $rs['level'];

		if ($rs['semester'] != $semester){
			$error[] = strtoupper(course($course,'course_code'))." is for ".semester(course($course,'semester'))." not ".semester($semester) ;
		}

		$staff = $db->query("SELECT * FROM course_offered_lecturer WHERE course_id ='$course' and staff_id='$staff_id' and semester ='$semester' and session='$session'");
		$num_row = $staff->rowCount();

		if ($num_row >= 1){
			$error[] = strtoupper(course($course,'course_code')).' was assigned for '.ucwords(staff_details($staff_id,'fname')).' in '.$session.' Academic Session for '.strtoupper(level(course($course,'level'))).' Students';
		}

		$error_count = count($error);
		if ($error_count == 0) {
			
			$in = $db->query("INSERT INTO course_offered_lecturer (staff_id,course_id,semester,session,schedule,level)
            VALUES('$staff_id','$course','$semester','$session','$schedule','$level')");

			set_flash(strtoupper(course($course,'course_code')).' was assign for '.ucwords(staff_details($staff_id,'fname')), 'warning');

		}else{
			$msg = "$error_count error(s) occur while assign course for lecturer, try again";
			foreach ($error as $value) {
				$msg.='<p>'.$value.'</p>';
			}
			set_flash($msg,'danger');
		}
	}
	require_once 'libs/head.php';
 ?>

 <section class="content-wrapper">
 	<div class="content-header">
 		<h3><?php echo $page_title; ?></h3>
 	</div>
 	<div class="content">
 		<div class="row">
 			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
 				<div class="box">
 					<div class="box-header">
 						<h5 class="box-title"><?php echo $page_title; ?></h5>
 					</div>
 					<div class="box-body">
 						<form method="post">
 							<?php flash(); ?>
 							<div class="form-group">
 								<label>Departmental Courses</label>
 								<select class="form-control select2 " name="course" required="" style="height: 48px;">
 									<option value="0">-- Select --</option>
 									<?php 
 										$sql = $db->query("SELECT * FROM course ORDER BY course_title");
 										while ($rs = $sql->fetch(PDO::FETCH_ASSOC)){
 											?>
 											<option value="<?php echo $rs['id'] ?>">COURSE CODE : <?php echo strtoupper($rs['course_code']); ?> : OFFERED LEVEL : <?php echo strtoupper(level($rs['level'])); ?> : OFFERED DEPT. <?php echo strtoupper( department($rs['dept'],'name')); ?></option>
 											<?php
 										}
 									 ?>
 								</select>
 							</div>

 							<div class="form-group">
 								<label>Semester</label>
 								<select class="form-control select2 " name="semester" required="" style="height: 48px;">
 									<option value="0">-- Select --</option>
 									<option value="1">First Semester</option>
 									<option value="2">Second Semester</option>
 								</select>
 							</div>

 							<div class="form-group">
 								<label>Academic Session</label>
 								<select class="form-control select2 " name="session" required="" style="height: 48px;">
 									<option value="0">-- Select --</option>
 									<?php 
 										foreach (range(2019, date('Y')) as $value) {
 											$y = $value-1;
 											$y.="/".$value;
 											echo '<option>'.$y.'</option>';
 										}
 									 ?>
 								</select>
 							</div>

 							<div class="form-group">
 								<label>Course Taken By</label>
 								<select class="form-control select2 " required="" name="by" style="height: 48px;">
 									<option value="0">-- Select -- </option>
 									<?php 
 										$sql = $db->query("SELECT * FROM admin ORDER BY username");
 										while ($rs = $sql->fetch(PDO::FETCH_ASSOC)){
 											?>
 											<option value="<?php echo $rs['id'] ?>"><?php echo ucwords($rs['fname']); ?> From <?php echo ucwords(department($rs['dept'],'name')); ?> Department</option>
 											<?php
 										}
 									 ?>
 								</select>
 							</div>
                            
                            <div class="form-group">
                                <label for="">Lecture Time Schedule</label>
                                <input type="text" name="schedule" id="" class="form-control" required placeholder="E.g 8:00am - 9:00am">
                            </div>

 							<div class="form-group">
 								<input type="submit" name="ok" class="btn btn-warning" value="Submit">
 							</div>
 						</form>
 					</div>
 				</div>
 			</div>
 		</div>
 	</div>
 </section>

 <?php require_once 'libs/foot.php'; ?>