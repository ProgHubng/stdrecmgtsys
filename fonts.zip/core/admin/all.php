<?php 
	$page_title = "Sas Admininistrative";
	require_once '../core/all.php';
	if (!is_admin_login()){
		header('location:index.php');
		exit();
	}
	require_once 'libs/head.php';
	require_once 'libs/menu.php';
 ?>

 <section class="content-wrapper">
 	<div class="content-header">
 		<h3><?php echo $page_title; ?></h3>
 	</div>
 	<div class="content">
 		<div class="row">
 			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
 				<div class="box">
	 				<div class="box-header with-border">
	 					<h5 class="box-title"><?php echo $page_title; ?></h5>
	 				</div>
	 				<div class="box-body">
	 					<table class="table table-condensed  table-striped table-hover">
	 						<thead>
	 							<tr>
	 								<th>S/No</th>
	 								<th>Photo</th>
	 								<th>Username</th>
	 								<th>Full Name</th>
	 								<th>Email Address</th>
	 								<th>Phone Number</th>
	 								<th>Registered Date</th>
	 							</tr>
	 						</thead>
	 						<tfoot>
	 							<tr>
	 								<th>S/No</th>
	 								<th>Photo</th>
	 								<th>Username</th>
	 								<th>Full Name</th>
	 								<th>Email Address</th>
	 								<th>Phone Number</th>
	 								<th>Registered Date</th>
	 							</tr>
	 						</tfoot>
	 						<tbody>
	 							<?php 
	 								$ii=1;
	 								$stmt = $db->prepare("SELECT * FROM admin WHERE role =:role ORDER BY id DESC");
	 								$stmt->execute(array(
	 									'role'=>'Admin'
	 								));
	 								while ($rs = $stmt->fetch(PDO::FETCH_ASSOC)){
	 									?>
	 									<tr>
	 										<td><?php echo $ii++; ?></td>
	 										<td><img src="../image/indesx.jpg" class="img-size img-circle img-thumbnail"></td>
	 										<td><?php echo $rs['username']; ?></td>
	 										<td><?php echo ucwords($rs['fname']); ?></td>
	 										<td><?php echo $rs['email']; ?></td>
	 										<td><?php echo $rs['phone']; ?></td>
	 										<td><?php echo $rs['add_date']; ?></td>
	 									</tr>
	 									<?php
	 								}
	 							 ?>
	 						</tbody>
	 					</table>
	 				</div>
	 			</div>
 			</div>
 		</div>
 	</div>
 </section>

 <?php require_once 'libs/foot.php'; ?>