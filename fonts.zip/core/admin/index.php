<?php 
	require_once '../core/all.php';
	if (is_admin_login()){
		header('location:dashboard.php');
		exit();
	}
	if (isset($_POST['login'])){
		$username = $_POST['username'];
		// $password = md5($_POST['password']);
		$password = $_POST['password'];

		$stmt = $db->prepare("SELECT username
		 FROM admin WHERE username =:username and password =:password");
		$stmt->execute(array('username'=>$username,'password'=>$password));
		$num = $stmt->rowCount();

		if ($num == 0){
			set_flash("Invalid login details, try again","danger");
			header("location:index.php");
			exit();
		}else{
			$_SESSION['admin'] = $username;
			header('location:dashboard.php');
			exit();
		}
		$stmt->closeCursor();
		var_dump($username);
	}
 ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>FPE &dash; Admin</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.css">
	<link rel="stylesheet" type="text/css" href="css/style-theme-min.css">
	<link rel="stylesheet" type="text/css" href="css/styles.css">
	<!-- path to google fonts -->
  <link href="http://fonts.googleapis.com/css?family=Roboto:400,300,500,700" rel="stylesheet" type="text/css">
</head>
<body>

	<header id="header">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
					<div class="header-logo">
						<img src="../image/logo.fw.png">
					</div>
				</div>
			</div>
		</div>
	</header>

	<section class="section-body">
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 col-lg-offset-3 col-md-offset-3">
						<form class="form-group mt-top" method="post" role="form">
							<h5 class="page-header">Admin Login</h5>
						
							<?php flash(); ?>
							<div class="form-group has-feedback">
								<label>Username</label>
								<div class="input-icon input-user">
								  <label class="control-label sr-only" for="inputSuccess5">Hidden label</label>
								  <input type="text" class="form-control" id="username" required="" placeholder="Enter your username *" name="username" aria-describedby="inputSuccess5Status">
								  <span class="glyphicon u glyphicon-remove text-danger form-control-feedback" aria-hidden="true"></span>
								  <span id="inputSuccess5Status" class="sr-only">(success)</span>
								</div>
							</div>

							<div class="form-group has-feedback">
								<label>Password</label>
								<div class="input-icon input-pass">
								  <label class="control-label sr-only" for="inputSuccess5">Hidden label</label>
								  <input type="password" class="form-control" id="password" required="" placeholder="Enter your password *" name="password" aria-describedby="inputSuccess5Status">
								  <span class="glyphicon p text-danger glyphicon-remove form-control-feedback" aria-hidden="true"></span>
								  <span id="inputSuccess5Status" class="sr-only">(success)</span>
								</div>
							</div>

							<div class="form-group">
								<input type="submit" name="login" class="btn btn-secondary" value="Login">
							</div>	
					</form>
				</div>
			</div>
		</div>
	</section>
	<script type="text/javascript" src="js/jQuery-2.2.0.min.js"></script>
	<script type="text/javascript" src="js/main.js"></script>
</body>
</html>