<?php 
	$page_title = "Staff Information";
	require_once '../core/all.php';
	if (!is_admin_login()) {
		header("location:index.php");
		exit();
	}
	if (isset($_POST['ok'])){
	   $level = $_POST['level'];
	   $dept = $_POST['dept'];
	   $session = $_POST['session'];
	   $semester = $_POST['semester'];
	   $staff_id = $_GET['staff-id'];

	   $error = array();
	   $errors = array('level'=>$level,'department'=>$dept,'session'=>$session,'semester'=>$semester);
	   foreach ($errors as $key => $value){
	       if ($value == 0){
	           $error[] = ucwords($key)." fields are required";
           }
       }

        $sql = $db->query("SELECT * FROM course WHERE level ='$level' and dept='$dept' and semester='$semester'");
        $num_row = $sql->rowCount();

        if ($num_row == 0){
            $error[] = "No course registered for ".department($dept)." Department ".strtoupper(level($level))." in ".semester($semester);
        }

	   $error_count = count($error);
	   if ($error_count == 0){

	       while ($rs = $sql->fetch(PDO::FETCH_ASSOC)){
	           $course_id = $rs['id'];

	           $sqls = $db->query("SELECT * FROM course_offered_lecturer WHERE staff_id ='$staff_id' and course_id ='$course_id' and session='$session' and semester ='$semester'");

	           //$num_rows = $sqls->rowCount();

               while ($rws = $sqls->fetch(PDO::FETCH_ASSOC)){
                   var_dump($rws);
               }
           }

       }else{
	       $msg = "$error_count error(s) occur while checking for offer course/semester, try again";
	       foreach ($error as $value){
	           $msg.='<p>'.$value.'</p>';
           }
	       set_flash($msg,'danger');
       }
    }
	require_once 'libs/head.php';
 ?>

 <section class="content-wrapper">
 	<div class="content-header">
 		<h3><?php echo $page_title; ?></h3>
 	</div>
 	<div class="content">
 		<div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="box">
                    <div class="box-header">
                        <h5 class="box-title"><?php echo $page_title;?></h5>
                    </div>
                    <div class="box-body">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Photo</th>
                                    <th>Full Name</th>
                                    <th>Email Address</th>
                                    <th>Phone Number</th>
                                    <th>Department</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th>Photo</th>
                                    <th>Full Name</th>
                                    <th>Email Address</th>
                                    <th>Phone Number</th>
                                    <th>Department</th>
                                    <th>Action</th>
                                </tr>
                            </tfoot>
                            <tbody>
                                <?php
                                    $id = $_GET['staff-id'];
                                    $sql = $db->query("SELECT * FROM admin WHERE id ='$id'");
                                    $rs = $sql->fetch(PDO::FETCH_ASSOC);
                                    if ($rs['image'] == ""){
                                        $img = "indesx.jpg";
                                    }else{
                                        $img = $rs['image'];
                                    }
                                    ?>
                                    <tr>
                                        <td><img src="../image/<?php echo $img;?>" class="img-size img-circle img-thumbnail" alt=""></td>
                                        <td><?php echo ucwords($rs['fname']);?></td>
                                        <td><?php echo $rs['email'];?></td>
                                        <td><?php echo $rs['phone'];?></td>
                                        <td><?php echo department($rs['dept'])?></td>
                                        <td><a href="" class="btn btn-outline-warning"><i class="fa fa-edit"></i> Update Profile</a></td>
                                    </tr>
                                    <?php
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <div class="box">
                    <div class="box-header">
                        <h5 class="box-title">Check Course Offered</h5>
                    </div>
                    <div class="box-body">
                        <?php flash(); ?>
                        <form action="" method="post" role="form">
                            <div class="form-group">
                                <label for="">Level</label>
                                <select name="level" class="form-control select2" id="">
                                    <option value="0">-- Select --</option>
                                    <?php
                                        $sql = $db->query("SELECT * FROM level ORDER BY name");
                                        while ($rs = $sql->fetch(PDO::FETCH_ASSOC)){
                                            echo '<option value="'.$rs['id'].'">'.strtoupper($rs['name']).'</option>';
                                        }
                                    ?>
                                </select>
                            </div>

                            <form action="" method="post" role="form">
                                <div class="form-group">
                                    <label for="">Department</label>
                                    <select name="dept" class="form-control select2" id="">
                                        <option value="0">-- Select --</option>
                                        <?php
                                        $sql = $db->query("SELECT * FROM department ORDER BY name");
                                        while ($rs = $sql->fetch(PDO::FETCH_ASSOC)){
                                            echo '<option value="'.$rs['id'].'">'.ucwords($rs['name']).'</option>';
                                        }
                                        ?>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label for="">Semester</label>
                                    <select name="semester" class="form-control select2" id="">
                                        <option value="0">-- Select --</option>
                                        <option value="1">First Semester</option>
                                        <option value="2">Second Semester</option>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label for="">Academic Session</label>
                                    <select name="session" class="form-control select2" id="">
                                        <option value="0">-- Select --</option>
                                        <?php
                                        foreach (range(2019,date('Y')) as $value){
                                            $y = $value-1;
                                            $y.='/'.$value;
                                            echo '<option>'.$y.'</option>';
                                        }
                                        ?>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <input type="submit" name="ok" class="btn btn-warning" value="Check" id="">
                                </div>
                        </form>
                    </div>
                </div>
            </div>

            <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
                <div class="box">
                    <div class="box-header">
                        <h5 class="box-title">Offered Courses </h5>
                    </div>
                    <div class="box-body">
                        <table class="table table-striped" id="example1">
                            <thead>
                                <tr>
                                    <th>S/N</th>
                                    <th></th>
                                    <th>Staff Full Name</th>
                                    <th>Staff Department</th>
                                    <th>Course Code</th>
                                    <th>Student Department</th>
                                    <th>Level</th>
                                    <th>Session</th>
                                    <th>Schedule</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th>S/N</th>
                                    <th></th>
                                    <th>Staff Full Name</th>
                                    <th>Staff Department</th>
                                    <th>Course Code</th>
                                    <th>Student Department</th>
                                    <th>Level</th>
                                    <th>Session</th>
                                    <th>Schedule</th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
 	</div>
 </section>

 <?php require_once 'libs/foot.php'; ?>