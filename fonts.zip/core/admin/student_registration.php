<?php 
	$page_title = "Student Registration";
	require_once '../core/all.php';
	if (!is_admin_login()){
		header('location:index.php');
		exit();
	}
	if (isset($_POST['ok-add'])){
		$matric = $_POST['matric'];
		$password = md5($matric);
		$fname = $_POST['fname'];
		$email = $_POST['email'];
		$phone = $_POST['phone'];
		$level = $_POST['level'];
		$prog = $_POST['prog'];
		$dept = $_POST['dept'];

		$error = array();

		$stmt = $db->prepare("SELECT NULL FROM students WHERE matric =:matric");
		$stmt->execute(array('matric'=>$matric));
		$rws_count = $stmt->rowCount();

		if ($rws_count >= 1){
			$error[] = 'Matric number has already been registered';
		}

		if (strlen($phone) != 11 or !is_numeric($phone)){
			$error[] = 'Invalid phone number format';
		}

		if (strlen($fname) < 10 or strlen($fname) > 50){
			$error[] = 'Invalid full name entered, it must be between 10 - 50 characters';
		}

		if (isset($_FILES['upl'])) {
			$files = $_FILES['upl'];
			$name = $files['name'];
			$allowed = array('jpg','png','jpeg');
			$folder = '../image/';
			$n = pathinfo($name,PATHINFO_EXTENSION);
			if ($name == ""){
				$error[] = 'Student profile image is required';
			}else{
				if (!in_array($n,$allowed)){
					$error[] = 'Invalid image type format, only jpg, png, jpeg is allowed';
				}else{
					if ($files['size'] > 1024 * 1024){
						$error[] = 'Maximum upload filesize is 50KB';
					}else{
						$tmp = time().'-'.uniqid().'-'.$name;
						$destination = $folder.$tmp;
					}
				}
			}
		}

		$error_count = count($error);
		if ($error_count == 0) {
			
			if (move_uploaded_file($_FILES['upl']['tmp_name'], $destination)){

				$last_year = date('Y')-1;
				$session = $last_year.'/'.date('Y');

				$in = $db->prepare("INSERT INTO students(matric,password,fname,level,prog,email,dept,phone,semester,session,stu_img,add_date)VALUES(:matric,:password,:fname,:level,:prog,:email,:dept,:phone,:semester,:session,:stu_img,:add_date)");
				$in->execute(array('matric'=>$matric,'password'=>$password,'fname'=>$fname,'level'=>$level,'prog'=>$prog,'email'=>$email,'dept'=>$dept,'phone'=>$phone,'semester'=>1,'session'=>$session,'stu_img'=>$tmp,'add_date'=>date('d M, Y')));

				set_flash("Your registration has been successfully","warning");
			}

		}else{
			$msg = "$error_count error(s) occur while register new student";
			foreach ($error as $value){
				$msg.= '<p>'.$value.'</p>';
			}
			set_flash($msg,"danger");
		}
	}
	require_once 'libs/head.php';
	
 ?>

 <section class="content-wrapper">
 	<div class="content-header">
 		<h3><?php echo $page_title; ?></h3>
 	</div>
 	<div class="content">
 		<div class="row">
 			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
 				<div class="box">
 					<div class="box-header with-border">
 						<h5 class="box-title"><?php echo $page_title; ?></h5>
 					</div>
 					<div class="box-body">
 						<form class="form-group" method="post" role="form" enctype="multipart/form-data">
 							<?php flash(); ?>
 							<div class="row">
 								<div class="col-sm-12">
 									<div class="form-group">
 										<label>Matric Number</label>
 										<input type="text" name="matric" class="form-control" maxlength="15" required="" placeholder="Matric Number">
 									</div>
 								</div>

 								<div class="col-sm-6">
 									<div class="form-group">
 										<label>Full Name</label>
 										<input type="text" name="fname" class="form-control" maxlength="50" required="" placeholder="Full Name">
 									</div>
 								</div>

 								<div class="col-sm-6">
 									<div class="form-group">
 										<label>Email Address</label>
 										<input type="email" name="email" maxlength="100" class="form-control" required="" placeholder="Email Address">
 									</div>
 								</div>

 								<div class="col-sm-6">
 									<div class="form-group">
 										<label>Phone Number</label>
 										<input type="text" maxlength="11" name="phone" class="form-control" required="" placeholder="Phone Number">
 									</div>
 								</div>

 								<div class="col-sm-6">
 									<div class="form-group">
 										<label>Mode / Level</label>
 										<select class="form-control custom-select" name="level" style="height: 48px;" required="">
 											<?php 
 												$stmt = $db->query("SELECT * FROM level");
 												$stmt->execute();
 												while ($rs = $stmt->fetch(PDO::FETCH_ASSOC)){
 													echo '<option value="'.$rs['id'].'">'.strtoupper($rs['name']).'</option>';
 												}
 											 ?>
 										</select>
 									</div>
 								</div>
 							</div>
 							<div class="row">
 								<div class="col-sm-6">
 									<div class="form-group">
 										<label>Programme</label>
 										<select class="form-control custom-select" style="height: 48px;" name="prog" required="">
 											<option>National Diploma</option>
 											<option>Higher National Diploma</option>
 										</select>
 									</div>
 								</div>

 								<div class="col-sm-6">
 									<div class="form-group">
 										<label>Department</label>
 										<select class="form-control custom-select" name="dept" required="" style="height: 48px">
 											<?php 
 												$stmt = $db->query("SELECT * FROM department");
 												$stmt->execute();
 												while ($rs = $stmt->fetch(PDO::FETCH_ASSOC)){
 													echo '<option value="'.$rs['id'].'">'.ucwords($rs['name']).'</option>';
 												}
 											 ?>
 										</select>
 									</div>
 								</div>
 							</div>

 							<div class="form-group">
 								<label>Upload Student Image</label>
 								<input type="file" name="upl" accept="image/*">
 							</div>

 							<div class="form-group">
 								<input type="submit" name="ok-add" class="btn btn-warning" value="Submit">
 							</div>
 						</form>
 					</div>
 				</div>
 			</div>
 		</div>
 	</div>
 </section>

 <?php require_once 'libs/foot.php'; ?>