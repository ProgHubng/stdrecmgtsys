<?php 
	$page_title = "Settings";
	require_once '../core/all.php';
	if (!is_admin_login()){
		header('location:index.php');
		exit();
	}
	if (isset($_POST['ok'])){
		$category = $_POST['category'];
		$status = $_POST['status'];
		$semester = $_POST['semester'];
		$session = $_POST['session'];

		$sql = $db->query("SELECT * FROM settings WHERE category ='$category' and session='$session'");
		$num_row = $sql->rowCount();

		if ($num_row >= 1){
		    $up = $db->query("UPDATE settings SET status ='$status', semester ='$semester', session='$session' WHERE category ='$category'");

        }else{
		    $in = $db->query("INSERT INTO settings (status,category,semester,session)
            VALUES ('$status','$category','$semester','$session')");
        }

        if ($status == 0){
            set_flash("$category has been ".status($status)." for ".semester($semester).' in '.$session. 'academic session ','danger');
        }else{
            set_flash("$category has been ".status($status)." for ".semester($semester).' in '.$session. ' academic session ','warning');
        }
	}
	require_once 'libs/head.php';
	
 ?>

 <section class="content-wrapper">
 	<div class="content-header">
 		<h3><?php echo $page_title; ?></h3>
 	</div>
 	<div class="content">
 		<div class="row">
 			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
 				<div class="box">
 					<div class="box-header">
 						<h5 class="box-title"><?php echo $page_title; ?></h5>
 					</div>
 					<div class="box-body">
 						<?php flash(); ?>
 						<form class="form-group" method="post" role="form">
 							<div class="form-group">
 								<label>Examination Status</label>
 								<select class="form-control select2 " name="status" style="height: 48px;">
 									<option value="0">Inactive</option>
 									<option value="1">Active</option>
 								</select>
 							</div>

 							<div class="form-group">
 								<label>Category</label>
 								<select class="form-control select2 " name="category" style="height: 48px" required="">
 									<option>Result</option>
 									<option>Registration</option>
 								</select>
 							</div>

 							<div class="form-group">
 								<label>Semester</label>
 								<select class="form-control select2 " required="" name="semester" style="height: 48px">
 									<option value="1">First Semester</option>
 									<option value="2">Second Semester</option>
 								</select>
 							</div>

 							<div class="form-group">
 								<label>Academic Session</label>
 								<select class="form-control select2 " name="session" style="height: 48px;">
 									<?php 
 										foreach (range(2019, date('Y')) as $value) {
 											$y = $value-1;
 											$y.="/".$value;
 											echo '<option>'.$y.'</option>';
 										}
 									 ?>
 								</select>
 							</div>

 							<div class="form-group">
 								<input type="submit" name="ok" class="btn btn-warning" value="Submit">
 							</div>
 						</form>
 					</div>
 				</div>
 			</div>
 		</div>
 	</div>
 </section>

 <?php require_once 'libs/foot.php'; ?>