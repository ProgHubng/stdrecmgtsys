<?php 
	$page_title = "";
	require_once '../core/all.php';
	if (!is_admin_login()){
		header('location:index.php');
		exit();
	}
	$slug = $_GET['slug'];
	$sql = $db->query("SELECT * FROM department WHERE slug ='$slug'");
	$rs = $sql->fetch(PDO::FETCH_ASSOC);
	$page_title = ucwords($rs['name']);
	$dept_id = $rs['id'];
	require_once 'libs/head.php';
	
 ?>

 <section class="content-wrapper">
 	<div class="content-header">
 		<h3><?php echo $page_title; ?></h3>
 	</div>
 	<div class="content">
 		<div class="row">
 			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
 				<div class="box">
 					<div class="box-header">
 						<?php echo $page_title; ?>
 					</div>
 					<div class="box-body">
 						<form method="post">
 							<table class="table text-uppercase table-striped table-hover" id="example1">
	 						<thead>
	 							<tr>
	 								<th>S/No</th>
	 								<th></th>
	 								<th>Photo</th>
	 								<th>Staff Id</th>
	 								<th>Full Name</th>
	 								<th>Email Address</th>
	 								<th>Phone Number</th>
	 								<th>Role</th>
	 								<th>Registered Date</th>
	 								<th>Actions</th>
	 							</tr>
	 						</thead>
	 						<tfoot>
	 							<tr>
	 								<th>S/No</th>
	 								<th></th>
	 								<th>Photo</th>
	 								<th>Staff Id</th>
	 								<th>Full Name</th>
	 								<th>Email Address</th>
	 								<th>Phone Number</th>
	 								<th>Role</th>
	 								<th>Registered Date</th>
	 								<th>Actions</th>
	 							</tr>
	 						</tfoot>
	 						<tbody>

	 							<?php 
	 								$ii = 1;
	 								$sql = $db->query("SELECT * FROM admin WHERE role='Staff' and dept ='$dept_id' ORDER BY id DESC");
	 								while ($rs = $sql->fetch(PDO::FETCH_ASSOC)) {
	 								    if ($rs['image'] == ""){
	 								        $img = "indesx.jpg";
                                        }else{
	 								        $img = $rs['image'];
                                        }
	 									?>
	 										<tr>
		 										<td><?php echo $ii++; ?></td>
		 										<th><input type="checkbox" name="select[]" value="<?php echo $rs['id']; ?>"></th>
		 										<td><img src="../image/<?php echo $img;?>" class="img-size img-circle img-thumbnail"></td>
		 										<td><?php echo $rs['username']; ?></td>
		 										<td><?php echo ucwords($rs['fname']); ?></td>
		 										<td><?php echo $rs['email']; ?></td>
		 										<td><?php echo $rs['phone']; ?></td>
		 										<td><?php echo $rs['role']; ?></td>
		 										<td><?php echo $rs['add_date']; ?></td>
		 										<td>
		 											<div class="btn-group">
		 												<a href="" class="btn btn-outline-warning">Update</a>
		 												<a href="staff_detail.php?staff-id=<?php echo $rs['id']; ?>" class="btn btn-warning">Details</a>
		 											</div>
		 										</td>
		 									</tr>
	 									<?php
	 								}
	 							 ?>

	 						</tbody>
	 					</table>

		 					<div class="form-group">
		 						<input type="submit" name="delete" class="btn btn-danger" value="Remove">
		 					</div>
 						</form>
 					</div>
 				</div>
 			</div>
 		</div>
 	</div>
 </section>
 <?php require_once 'libs/foot.php'; ?>