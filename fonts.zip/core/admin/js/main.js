$(function(){
	$("#username, #password").on('keyup', function(){
        var u = $("#username").val();
        var p = $("#password").val();
        if (u.length > 4) {
            $(".u").removeClass('glyphicon-remove');
            $(".u").addClass('glyphicon-ok');
            $('.u').removeClass('text-danger');
            $('.u').addClass('text-success');
        }else{
            $(".u").addClass('glyphicon-remove');
            $(".u").removeClass('glyphicon-ok');
            $('.u').addClass('text-danger');
            $('.u').removeClass('text-success');
        }

        if (p.length > 2) {
            $(".p").removeClass('glyphicon-remove');
            $(".p").addClass('glyphicon-ok');
            $('.p').removeClass('text-danger');
            $('.p').addClass('text-success');
        }else{
            $(".p").addClass('glyphicon-remove');
            $(".p").removeClass('glyphicon-ok');
            $('.p').addClass('text-danger');
            $('.p').removeClass('text-success');
        }
    });
});