<?php 
	$page_title = "Add New Department";
	require_once '../core/all.php';
	if (!is_admin_login()) {
		header("location:index.php");
		exit();
	}
	if (isset($_POST['ok'])) {
		$name = $_POST['name'];
		$slug = str_replace(" ", "-", strtolower($name));

		$error = array();

		if (strlen($name) >= 50 or strlen($name) < 5) {
			$error[] = "The department name should be between 5 - 50, try again";
		}

		$sql = $db->query("SELECT NULL FROM department WHERE name ='$name'");
		$num_row = $sql->rowCount();

		if ($num_row >= 1) {
			$error[] = "The department name has already exit, try again";
		}

		$error_count = count($error);
		if ($error_count == 0) {
			
			$in = $db->query("INSERT INTO department (name,slug)VALUES('$name','$slug')");
			set_flash("The department name was added successfully","warning");

		}else{
			$msg = "$error_count error(s) occur while add new department try again";
			foreach ($error as $value) {
				$msg.='<p>'.$value.'</p>';
			}
			set_flash($msg,'danger');
		}
	}
	require_once 'libs/head.php';
 ?>

 <section class="content-wrapper">
 	<div class="content-header">
 		<h3><?php echo $page_title; ?></h3>
 	</div>
 	<div class="content">
 		<div class="row">
 			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
 				<div class="box">
 					<div class="box-header">
 						<?php echo $page_title; ?>
 					</div>
 					<div class="box-body">
 						
 						<form class="form-group" method="post" role="form">

 							<?php flash(); ?>
 							<div class="form-group">
 								<label>Department Name</label>
 								<input type="text" name="name" class="form-control" required="" placeholder="Department Name">
 							</div>

 							<div class="form-group">
 								<input type="submit" name="ok" class="btn btn-warning" value="Submit">
 							</div>
 						</form>

 					</div>
 				</div>
 			</div>
 		</div>
 	</div>
 </section>

 <?php require_once 'libs/foot.php'; ?>