<?php 
	$page_title = "Add Course Registration";
	require_once '../core/all.php';
	if (!is_admin_login()) {
		header("location:index.php");
		exit();
	}
	if (isset($_POST['ok-add'])){
		$course_title = $_POST['course-title'];
		$course_code = $_POST['course-code'];
		$course_unit = $_POST['course-unit'];
		$semester = $_POST['semester'];
		$department = $_POST['dept'];
		$level = $_POST['level'];

		$err = array();

		$stmt = $db->prepare("SELECT NULL FROM course WHERE course_title =:course_title and dept =:dept and course_code =:course_code and course_unit =:course_unit and level =:level");
		
		$stmt->execute(array(
				'course_title'=>$course_title,
				'dept'=>$department,
				'course_code'=>$course_code,
				'course_unit'=>$course_unit,
				'level'=>$level,
			));

		$rws_count = $stmt->rowCount();

		if ($rws_count >= 1){
			$err[] = "Thise course has already registered for ".ucfirst(department($department))." department and ".strtoupper(level($level))." level";
		}

		$err_count = count($err);
		if ($err_count ==0) {
			
			$in = $db->prepare("INSERT INTO course (course_title,course_code,course_unit,level,dept,semester,add_date)VALUES(:course_title,:course_code,:course_unit,:level,:dept,:semester,:add_date)");

			$in->execute(array(
				'course_title'=>$course_title,
				'course_code'=>$course_code,
				'course_unit'=>$course_unit,
				'level'=>$level,
				'dept'=>$department,
				'semester'=>$semester,
				'add_date'=>date('m F, Y')
			));

			set_flash(ucfirst(department($department)).' departmental course has been added','warning');

		}else{
			$msg = "$err_count error(s) occur while adding departmental course, try again";
			foreach ($err as $value) {
				$msg.='<p>'.$value.'</p>';
			}
		set_flash($msg,"danger");
		}
	}
	require_once 'libs/head.php';
 ?>

 <section class="content-wrapper">
 	<div class="content-header">
 		<h3><?php echo $page_title; ?></h3>
 	</div>
 	<div class="content">
 		<div class="row">
 			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
 				<div class="box">
 					<div class="box-header">
 						<?php echo $page_title; ?>
 					</div>
 					<div class="box-body">
 						
 						<form class="form-group" method="post" role="form">
              		<?php flash(); ?>
              		<div class="row">
              			<div class="col-sm-6">
              				<div class="form-group">
              					<label>Course Title (+)</label>
              					<input type="text" name="course-title" class="form-control form-lg" required="" placeholder="Course Title" maxlength="100">
              				</div>
              			</div>

              			<div class="col-sm-6">
              				<div class="form-group">
              					<label>Course Code (+)</label>
              					<input type="text" name="course-code" class="form-control form-lg" required="" maxlength="10" placeholder="Course Code">
              				</div>
              			</div>

              			<div class="col-sm-12">
              				<div class="form-group">
              					<label>Course Unit (+)</label>
              					<input type="text" name="course-unit" pattern= "[0-9]" class="form-control form-lg" required="" placeholder="Course Unit" maxlength="1">
              				</div>
              			</div>

              			<div class="col-sm-6">
              				<div class="form-group">
              					<label>Semester (+)</label>
              					<select class="form-control select2  custom-select" name="semester" required="">
              						<option value="1">First Semester</option>
              						<option value="2">Second Semester</option>
              					</select>
              				</div>
              			</div>

              			<div class="col-sm-6">
              				<div class="form-group">
              					<label>Department (+)</label>
              					<select class="form-control select2 " style="height: 45px;" name="dept" required="">
              						<?php 	
										$department = $db->prepare("SELECT id,name FROM department ORDER BY name");
										$department->execute();
										while ($rs = $department->fetch(PDO::FETCH_ASSOC)){
											echo '<option value="'.$rs['id'].'">'.ucwords($rs['name']).'</option>';
										}
									              						
									 ?>
              					</select>
              				</div>
              			</div>

              			<div class="col-sm-12">
              				<div class="form-group">
              					<label>Departmental Level (+)</label>
              					<select class="form-control select2 " style="height: 45px;" name="level" required="">
              						<?php 
              							$stmt_level = $db->prepare("SELECT * FROM level ORDER BY name");
										$stmt_level->execute();
										while ($rss = $stmt_level->fetch(PDO::FETCH_ASSOC)){
											echo '<option value="'.$rss['id'].'">'.strtoupper($rss['name']).'</option>';
										}
              						 ?>
              					</select>
              				</div>
              			</div>

              		</div>

              		<div class="form-group">
              			<input type="submit" name="ok-add" class="btn btn-primary" value="Add course">
              		</div>

              	</form>

 					</div>
 				</div>
 			</div>
 		</div>
 	</div>
 </section>

 <?php require_once 'libs/foot.php'; ?>