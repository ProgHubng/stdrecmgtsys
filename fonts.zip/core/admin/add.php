<?php 
	$page_title = "Add New Admin / Staff";
	require_once '../core/all.php';
	if (!is_admin_login()){
		header('location:index.php');
		exit();
	}
	if (isset($_POST['ok-add'])){
		$username = $_POST['username'];
		$password = md5($username);
		$fname = $_POST['fname'];
		$email = $_POST['email'];
		$phone = $_POST['phone'];
		$dept = $_POST['dept'];
		$role = $_POST['role'];

		$error = array();

		$stmt = $db->prepare("SELECT NULL FROM admin WHERE username =:username");
		$stmt->execute(array('username'=>$username));
		$rws_count = $stmt->rowCount();

		if ($rws_count >= 1){
			$error[] = 'Invalid username entered, it has already been registered please choose another username';
		}

		if (strlen($username) > 15 or strlen($username) < 5){
			$error[] = 'Invalid username entered, it must be between 5 - 15 characters';
		}

		if (strlen($fname) > 50 or strlen($fname) < 10){
			$error[] = 'Invalid full name entered, it must be between 10 - 50 characters';
		}

		if (strlen($email) > 100){
			$error[] = 'Invalid email address entered, it must not excceed 100 characters';
		}

		if (strlen($phone) != 11 or !is_numeric($phone)){
			$error[] = 'Invalid phone number format, it must not excceed 11 digit and cannot be mismatch with characters';
		}

		if (isset($_FILES['upl'])) {
			$files = $_FILES['upl'];
			$name = $files['name'];
			$allowed = array('jpg','png','jpeg');

			$path = pathinfo($name, PATHINFO_EXTENSION);
			
			if (!in_array($path, $allowed)) {
				$error[] = "Invalid ";
			}

			if ($files['size'] > 1024 * 1024 * 1){
				$error[] = "Maximum filesize is 1MB, try again";
			}

			$folder = "../image/";
			$n = time().$name;
			$destination = $folder.$n;

		}

		$error_count = count($error);
		if ($error_count == 0){

			if (move_uploaded_file($_FILES['upl']['tmp_name'], $destination)) {
				
				$in = $db->prepare("INSERT INTO admin (username,password,fname,email,phone,add_date,role,dept,image,status)VALUES(:username,:password,:fname,:email,:phone,:add_date,:role,:dept,:image,:status)");

				$in->execute(array(
					'username'=>$username,
					'password'=>$password,
					'fname'=>$fname,
					'email'=>$email,
					'phone'=>$phone,
					'add_date'=>date('d M, Y'),
					'role'=>$role,
					'dept'=>$dept,
					'image'=>$n,
					'status'=>1
				));

				set_flash("Your registration has beem successfully","warning");

			}

		}else{
			$msg = "$error_count error(s) occur while register new staff";
			foreach ($error as $value){
				$msg.= '<p>'.$value.'</p>';
			}
			set_flash($msg,"danger");
		}
	}
	require_once 'libs/head.php';
	
 ?>

 <section class="content-wrapper">
 	<div class="content-header">
 		<h3><?php echo $page_title; ?></h3>
 	</div>
 	<div class="content">
 		<div class="row">
 			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
 				<div class="box">
 					<div class="box-header with-border">
 						<h5 class="box-title"><?php echo $page_title; ?></h5>
 					</div>
 					<div class="box-body">
 						<form class="form-group" method="post" role="form" enctype="multipart/form-data">
 							<?php flash();?>
 							<div class="row">
 								<div class="col-sm-12">
 									<div class="form-group">
 										<label>Username / staff id</label>
 										<input type="text" name="username" class="form-control" required="" placeholder="Username / staff id">
 									</div>
 								</div>

 								<div class="col-sm-6">
 									<div class="form-group">
 										<label>Full Name</label>
 										<input type="text" name="fname" class="form-control" required="" placeholder="Full Name">
 									</div>
 								</div>

 								<div class="col-sm-6">
 									<div class="form-group">
 										<label>Email Address</label>
 										<input type="email" name="email" class="form-control" required="" placeholder="Email Address">
 									</div>
 								</div>

 								<div class="col-sm-6">
 									<div class="form-group">
 										<label>Phone Number</label>
 										<input type="text" name="phone" class="form-control" required="" placeholder="Phone Number">
 									</div>
 								</div>

 								<div class="col-sm-6">
 									<div class="form-group">
 										<label>Role</label>
 										<select class="form-control select2 " required="" id="role" style="height: 45px;" name="role">
 											<option>-- Select --</option>
 											<option>Global Admin</option>
 											<option>Staff</option>
 										</select>
 									</div>
 								</div>

 								<!-- <div class="col-sm-6">
 									<div class="form-group">
 										<label>Password</label>
 										<input type="password" name="password" class="form-control" required="" placeholder="Password">
 									</div>
 								</div>

 								<div class="col-sm-6">
 									<div class="form-group">
 										<label>Confirm Password</label>
 										<input type="password" name="cpassword" class="form-control" required="" placeholder="Confirm Password">
 									</div>
 								</div>
 -->
 								<div class="col-sm-12">
	 								<div class="form-group" id="hide">
	 									<label>Department</label>
	 									<select class="form-control select2     " name="dept" required="" style="height: 45px;">
	 										<option>-- Select -- </option>
	 										<?php 
	 											$sql = $db->query("SELECT * FROM department ORDER BY name");
	 											while ($rs = $sql->fetch(PDO::FETCH_ASSOC)) {
	 												echo '<option value="'.$rs['id'].'">'.ucwords($rs['name']).'</option>';
	 											}
	 										 ?>
	 									</select>
	 								</div>
	 							</div>
 							</div>

 							<div class="form-group">
 								<label>Passport</label>
 								<input type="file" name="upl" required="" accept="image/*">
 								<small>Maximum upload filesize : 1MB</small>
 							</div> 							

 							<div class="form-group">
 								<input type="submit" name="ok-add" class="btn btn-warning" value="Submit">
 							</div>
 						</form>
 					</div>
 				</div>
 			</div>
 		</div>
 	</div>
 </section>

 <?php require_once 'libs/foot.php'; ?>