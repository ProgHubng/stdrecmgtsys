<?php 
	$page_title = "";
	require_once '../core/all.php';
	if (!is_admin_login()){
		header('location:index.php');
		exit();
	}
	$id = $_GET['id'];
	$stmt = $db->prepare("SELECT * FROM students WHERE id =:id");
	$stmt->execute(array('id'=>$id));
	$rs = $stmt->fetch(PDO::FETCH_ASSOC);
	$page_title = strtoupper($rs['matric']);

	$student_level = $rs['level'];
	$student_dept = $rs['dept'];
	$student_id = $rs['id'];
	$semester = $rs['semester'];
	$matric = $rs['matric'];
	// var_dump($rs);
	// exit();

	$prog = $rs['prog'];
	if (isset($_POST['ok-up'])){
		$level = $_POST['level'];
		$semester = $_POST['semester'];
		$up = $db->prepare("UPDATE students SET level =:level, semester =:semester WHERE id =:id");
		$up->execute(array('level'=>$level,'semester'=>$semester,'id'=>$id));
		set_flash("Student status has been updated","success");
	}

	if (isset($_GET['delete'])){
		$del = $db->prepare("DELETE FROM result WHERE id =:id");
		$del->execute(array('id'=>$_GET['delete']));
		set_flash("Semester result has been deleted","success");
		header("location:view.php?id=$id");
		exit();
	}
	if (isset($_POST['ok'])){
	    $semester = $_POST['semester'];
	    $session = $_POST['session'];

	    $sql = $db->query("SELECT * FROM registered_course WHERE student_id ='$student_id' and semester ='$semester' and session ='$session' and level='$student_level'");
	    $num_row = $sql->rowCount();

	    if ($num_row == 0){
	        set_flash("No registered course","danger");
        }else{
	        while ($rows = $sql->fetch(PDO::FETCH_ASSOC)){
	            $rows_1['course_id'][] = $rows['course_id'];

            }
            $in = $db->query("INSERT INTO student_result_status (student_id,semester,result,session)
                    VALUES ('$student_id','1','','$session')");
        }
    }
	if (isset($_POST['upload'])){
	    $category = $_POST['category'];
	    $session = $_POST['session'];
	    @$course_id = $_POST['course-id'];
	    @$score = $_POST['score'];

	    $error = array();

	    if ($score == 0){
	        $error[] = "Error";
        }

//	    if (!is_numeric($score)){
//	        $error[] = "Please examination score must be only number, try again";
//        }

	    for ($k =0;  $k < count($course_id); $k++){

	        $course_id_2 = $course_id[$k];

            $sql = $db->query("SELECT * FROM results WHERE course_id ='$course_id_2' and matric ='$matric' and semester ='$semester' and session='$session'");
            $num_row = $sql->rowCount();

            if ($num_row >= 1){
                $error[] = strtoupper(course($course_id_2,'course_code')).' has already been grade';
            }
        }


	    $error_count = count($error);
	    if ($error_count == 0){

            for($j =0; $j < count($course_id); $j++){

                $score_1 = $score[$j];
                $course_1_id = $course_id[$j];

                $in = $db->query("INSERT INTO results (course_id,matric,score,level,semester,category,session)
                VALUES ('$course_1_id','$matric','$score_1','$student_level','$semester','$category','$session')");

            }

            set_flash("The semester result was uploaded successfully","warning");

        }else{
	        $msg = "$error_count error(s) occur while uploading semester result, try again";
	        foreach ($error as $value){
	            $msg.='<p>'.$value.'</p>';
            }
	        set_flash($msg,'danger');
        }

    }
	require_once 'libs/head.php';
 ?>

 <section class="content-wrapper">
 	<div class="content-header">
 		<h3>Student Details</h3>
 	</div>
 	<div class="content">
 		<div class="row">
 			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
 				<div class="box">
 					<div class="box-header with-border">
 						<h4 class="box-title">Student Details</h4>
 					</div>
 					<div class="box-body">
 						<?php flash(); ?>
 						<table class="table table-striped table-hover">
 							<thead>
 								<tr>
	 								<th>Photo</th>
	 								<th>Matric Number</th>
	 								<th>Full Name</th>
	 								<th>Email Address</th>
	 								<th>Phone Number</th>
	 								<th>Department</th>
	 								<th>Programe</th>
	 								<th>Semester</th>
	 								<th>Session</th>
	 								<th>Level</th>
	 							</tr>
 							</thead>
 							<tfoot>
 								<tr>
 									<th>Photo</th>
	 								<th>Matric Number</th>
	 								<th>Full Name</th>
	 								<th>Email Address</th>
	 								<th>Phone Number</th>
	 								<th>Department</th>
	 								<th>Programe</th>
	 								<th>Semester</th>
	 								<th>Session</th>
	 								<th>Level</th>
 								</tr>
 							</tfoot>
 							<tbody>
 								<?php 
 									$stmt = $db->prepare("SELECT * FROM students WHERE id =:id");
 									$stmt->execute(array('id'=>$id));
 									while ($rs = $stmt->fetch(PDO::FETCH_ASSOC)){
 										?>
 										<tr>
 											<td><img src="../image/<?php echo $rs['stu_img']; ?>" class="img-size img-circle img-thumbnail"></td>
 											<td><?php echo strtoupper($rs['matric']); ?></td>
 											<td><?php echo strtoupper($rs['fname']); ?></td>
 											<td><?php echo $rs['email']; ?></td>
 											<td><?php echo $rs['phone']; ?></td>
 											<td><?php echo ucwords(department($rs['dept'])); ?></td>
 											<td><?php echo $rs['prog']; ?></td>
 											<td><?php echo semester($rs['semester']); ?></td>
 											<td><?php echo $rs['session']; ?></td>
 											<td><?php echo ucwords(level($rs['level'])); ?></td>
 										</tr>
 										<?php
 									}
 								 ?>
 							</tbody>
 						</table>
 					</div>
 				</div>
 		
			</div>

            <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
                <div class="box">
                    <div class="box-header">
                        <span class="box-title">Check student registered course / semester</span>
                    </div>
                    <div class="box-body">

                        <form action="" method="post">
                            <div class="form-group">
                                <label for="">Semester</label>
                                <select name="semester" class="form-control select2">
                                    <option value="1">First Semester</option>
                                    <option value="2">Second Semester</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="">Academic Session</label>
                                <select name="session" class="form-control select2" id="">
                                    <?php
                                        foreach (range(2019, date('Y')) as $value){
                                            $session = $value-1;
                                            $session.='/'.$value;
                                            echo '<option>'.$session.'</option>';
                                        }
                                    ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <input type="submit" name="ok" class="btn btn-warning" value="Submit" id="">
                            </div>
                        </form>

                    </div>
                </div>
            </div>

            <div class="col-lg-7 col-md-7 col-sm-12 col-xs-12">
                <div class="box">
                    <div class="box-header">
                        <span class="box-title">Upload Result</span>
                    </div>
                    <div class="box-body">
                        <form action="" method="post">
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="">Category</label>
                                        <select name="category" id="" class="form-control select2">
                                            <option value="1">Regular</option>
                                            <option value="2">Summer</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="">Academic Session</label>
                                        <select name="session" id="" class="form-control select2">
                                            <?php
                                                foreach (range(2019, date('Y')) as $value){
                                                    $session = $value-1;
                                                    $session.='/'.$value;
                                                    echo '<option>'.$session.'</option>';
                                                }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <?php
                                    $course_id = @$rows_1['course_id'];

                                    for($k =0; $k < count($course_id); $k++){
                                        $course_id_1 = $course_id[$k];

                                        $sql = $db->query("SELECT * FROM registered_course WHERE course_id ='$course_id_1' and student_id ='$student_id' and semester ='$semester' and session='$session'");
                                        while ($rs = $sql->fetch(PDO::FETCH_ASSOC)){
                                           ?>
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="">Course Code: <?php echo strtoupper(course($rs['course_id'],'course_code'));?></label>
                                                    <input type="hidden" name="course-id[]" id="" value="<?php echo $course_id_1;?>">
                                                    <input type="number" name="score[]" id="" maxlength="3" class="form-control" placeholder="Examination Score for <?php echo strtoupper(course($rs['course_id'],'course_code')) ?>">
                                                </div>
                                            </div>
                                          <?php
                                        }

                                    }
                                ?>
                            </div>

                            <div class="form-group">
                                <input type="submit" name="upload" class="btn btn-warning" value="Upload" id="">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
 		</div>
 	</div>
 </section>

 <?php require_once 'libs/foot.php'; ?>