<!-- Main Footer -->
  <footer class="main-footer">
    <!-- To the right -->
  <!--   <div class="pull-right hidden-xs">
      Designed By <a href="#">Matanmi</a>
    </div> -->
    <!-- Default to the left -->
    <!--   <span>Copyright &copy; <?php //echo date("Y"); ?> <a href="../index.php" target="_blank">National Population Commission (NPopC).</a>.</span> All rights reserved.
  </footer>
 -->
<div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<!-- REQUIRED JS SCRIPTS -->

<!-- jQuery 2.2.0 -->
<script src="js/jquery-1.11.1.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="js/bootstrap.min.js"></script>
<!-- AdminLTE App -->
<script src="js/app.min.js"></script>
<script src="datatables/jquery.dataTables.min.js"></script>
<script src="select2/select2.full.min.js"></script>
<script src="datatables/dataTables.bootstrap.min.js"></script>
<script type="text/javascript" src="js/uploadpreview.js"></script>
<script type="text/javascript" src="js/preview.js"></script>
<script type="text/javascript">

  $(function () {
    $("#example1").DataTable();
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false
    });

      $(".select2").select2();

    // $("#hide").hide();
    
    //  $("#role").change(function(e){
    //     if ($(this).val() == "Admin") {
    //         $("#hide").hide();
    //     }else{
    //         $("#hide").show();
    //     }
    // });

    $.uploadPreview({
      input_field: "#image-upload",
      preview_box: "#image-preview",
      label_field: "#image-label"
    });
  });

    
</script>
<!-- Optionally, you can add Slimscroll and FastClick plugins.
     Both of these plugins are recommended to enhance the
     user experience. Slimscroll is required when using the
     fixed layout. -->
</body>
</html>
