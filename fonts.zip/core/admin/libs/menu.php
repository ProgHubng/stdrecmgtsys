<div class="wrapper">

  <!-- Main Header -->
  <header class="main-header">

    <!-- Logo -->
    <a href="dashboard.php" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini">FPO SAS</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg">FPO SAS</span>
    </a>

    <!-- Header Navbar -->
    <nav class="navbar navbar-static-top" role="navigation">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
      <!-- Navbar Right Menu -->
      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <!-- User Account Menu -->
          <li class="dropdown user user-menu">
            <!-- Menu Toggle Button -->
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <!-- The user image in the navbar-->
              <?php 
                if (admin_detail('image') == ""){
                  $img_url = "indesx.jpg";
                }else{
                  $img_url = admin_detail('image');
                }
               ?>
              <img src="../image/<?php echo $img_url; ?>" class="user-image" alt="User Image">
              <!-- hidden-xs hides the username on small devices so only the image appears. -->
               <span class="hidden-xs"><?php echo ucwords(admin_detail('username')); ?></span>
            </a>
            <ul class="dropdown-menu">
              <!-- The user image in the menu -->
              <li class="user-header">
                <img src="../image/<?php echo $img_url; ?>" class="img-circle" alt="User Image">
                <p>
                 <?php echo ucfirst(admin_detail('username')); ?>
                  <small>Member since <?php echo admin_detail('add_date'); ?></small>
                </p>
              </li>
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <a href="update_profile.php" class="btn btn-default btn-flat">Profile</a>
                </div>
                <div class="pull-right">
                  <a href="update_password.php" class="btn btn-default btn-flat">Change Password</a>
                </div>
              </li>
            </ul>
          </li>
        </ul>
      </div>
    </nav>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">

    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

      <!-- Sidebar user panel (optional) -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="../image/<?php echo $img_url; ?>" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p><?php echo ucfirst(admin_detail('username')); ?></p>
          <!-- Status -->
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      <!-- Sidebar Menu -->
      <ul class="sidebar-menu">
        <!-- Optionally, you can add icons to the links -->
        <li><a href="dashboard.php"><i class="fa fa-home text-purple"></i> <span>FPO Dashboard</span></a></li>

         <li class="treeview">
              <a href=""><i class="fa fa-university text-success"></i> <span>FPO SAS Departments </span> <i class="fa fa-angle-left pull-right"></i></a>
               <ul class="treeview-menu">
                  <li><a href="add_new_department.php"><i class="fa fa-circle-o"></i> <span>Add New FPO Department</span></a></li>
<!--                  <li><a href="all_registered_student.php"><i class="fa fa-circle-o"></i> <span>FPO Total Student Reg/Session</span></a></li>-->
              </ul>
          </li>
         
         <li class="treeview">
              <a href=""><i class="glyphicon glyphicon-user text-warning"></i> <span>FPO SAS Admin / Staff </span> <i class="fa fa-angle-left pull-right"></i></a>
              <ul class="treeview-menu">
                  <li><a href="add.php"><i class="fa fa-circle-o"></i> <span>Add Administrative / Staff</span></a></li>
                  <li>
                      <a href="#"><i class="fa fa-circle-o"></i> SAS Administrative <i class="fa fa-angle-left pull-right"></i></a>
                      <ul class="treeview-menu">
                        <li><a href="all.php"><i class="fa fa-circle-o"></i> Administrative </a></li>
                        <li><a href="#"><i class="fa fa-circle-o"></i> Departmental Staff <i class="fa fa-angle-left pull-right"></i></a>
                          <ul class="treeview-menu">
                            <?php 
                                $sql = $db->query("SELECT * FROM department ORDER BY name");
                                while ($rs = $sql->fetch(PDO::FETCH_ASSOC)) {
                                    ?>
                                         <li><a href="sas_staff_department.php?slug=<?php echo $rs['slug'] ?>"><i class="fa fa-circle-o"></i> <span><?php echo ucwords($rs['name']); ?></span></a></li>
                                    <?php
                                }
                             ?>
                          </ul>
                        </li>
                      </ul>
                    </li>
                  
                  </li>
              </ul>
          </li>

          <li class="treeview">
              <a href="#">
                  <i class="fa fa-files-o text-info"></i>
                  <span>FPO SAS Course Reg.</span> <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                  <li><a href="add_course_registration.php"><i class="fa fa-circle-o"></i> Add Departmental Course</a></li><li>

                      <a href=""><i class="fa fa-circle-o"></i> Departmental Courses <i class="fa fa-angle-left pull-right"></i></a>
                      <ul class="treeview-menu">
                          <?php
                          $sql = $db->query("SELECT * FROM department ORDER BY name");
                          while ($rs = $sql->fetch(PDO::FETCH_ASSOC)){
                              ?>
                              <li>
                                  <a href="#"><i class="fa fa-circle-o"></i> <span> <?php echo substr(ucwords($rs['name']), 0,20),str_repeat('.', 1); ?> </span><i class="fa fa-angle-left pull-right"></i></a>
                                  <ul class="treeview-menu">
                                      <?php
                                      $sqls = $db->query("SELECT * FROM level ORDER BY name");
                                      while ($fpo_rs_l = $sqls->fetch(PDO::FETCH_ASSOC)){
                                          ?>
                                          <li><a href="registered_course.php?slug=<?php echo $fpo_rs_l['slug'] ?>&slugs=<?php echo $rs['slug'] ?>"><i class="fa fa-circle-o"></i> <span><?php echo strtoupper($fpo_rs_l['name']); ?></span></a></li>
                                          <?php
                                      }
                                      ?>
                                  </ul>
                              </li>
                              <?php
                          }
                          ?>
                          </li>
                      </ul>
                  </li>
              </ul>
          </li>

           <li class="treeview">
              <a href="#"><i class="fa fa-university text-primary"></i> <span>School Of Apply Sciences</span><i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">

                  <li><a href="add_level.php"><i class="fa fa-circle-o"></i> <span>Level</span></a></li>
                  <li><a href="student_registration.php"><i class="fa fa-user-plus"></i> Student Registration</a></li>
                <?php 
                  $sql = $db->query("SELECT * FROM department ORDER BY name");
                  while ($rs = $sql->fetch(PDO::FETCH_ASSOC)){
                      ?>
                       <li>
                          <a href="#"><i class="fa fa-circle-o"></i> <span> <?php echo substr(ucwords($rs['name']), 0,20),str_repeat('.', 1); ?> </span><i class="fa fa-angle-left pull-right"></i></a>
                          <ul class="treeview-menu">
                            <?php 
                              $sqls = $db->query("SELECT * FROM level ORDER BY name");
                              while ($fpo_rs_l = $sqls->fetch(PDO::FETCH_ASSOC)){
                                ?>
                                 <li><a href="level.php?slug=<?php echo $fpo_rs_l['slug'] ?>&slugs=<?php echo $rs['slug'] ?>"><i class="fa fa-circle-o"></i> <span><?php echo strtoupper($fpo_rs_l['name']); ?></span></a></li>
                                <?php
                              }
                             ?>
                          </ul>
                        </li>
                      <?php
                  }
                 ?>
              </ul>
        </li>

<!--        <li class="treeview">-->
<!--            <a href=""><i class="fa fa-file-pdf-o"></i> <span>FPE SAS Result Checking</span> <i class="fa fa-angle-left pull-right"></i></a>-->
<!--            <ul class="treeview-menu">-->
<!--               <li><a href=""><i class="fa fa-circle-o"></i> <span>Continues Assesments</span></a></li>-->
<!--            </ul>-->
<!--        </li>-->

        <li class="treeview">
          <a href=""><i class="fa fa-folder-o text-gold"></i> <span>Course Taken By Lecturer</span><i class="fa fa-angle-left pull-right"></i></a>
          <ul class="treeview-menu">
            <li><a href="assign_course.php"><i class="fa fa-circle-o"></i> <span>Assign Course For Lecturer</span></a></li>
            <li><a href="all_course_offered.php"> <i class="fa fa-circle-o"></i> <span>Check Offered Courses</span></a></li>
          </ul>
        </li>

        <li class="treeview"><a href=""><i class="fa fa-wrench text-pink "></i>
          <span>FPO SAS Settings</span><i class="fa fa-angle-left pull-right"></i></a>
          <ul class="treeview-menu">
            <li><a href="status.php"><i class="fa fa-circle-o"></i> <span>FPO SAS Settings</span></a></li>
          </ul>
        </li>

        <li><a href="logout.php"><i class="fa fa-sign-out text-red"></i><span> Logout</span></a></li>
      </ul>
      <!-- /.sidebar-menu -->
    </section>
    <!-- /.sidebar -->
  </aside>
