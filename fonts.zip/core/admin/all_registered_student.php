<?php 
	$page_title = "";
	require_once '../core/all.php';
	if (!is_admin_login()) {
		header("location:index.php");
		exit();
	}
	require_once 'libs/head.php';
 ?>

 <section class="content-wrapper">
 	<div class="content-header">
 		<h3><?php echo $page_title; ?></h3>
 	</div>
 	<div class="content">
 		<div class="row">
 			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
 				<div class="box">
 					<div class="box-header">
 						All <?php echo $page_title; ?> Students
 					</div>
 					<div class="box-body">
 						<table class="table table-striped table-hover text-uppercase">
 							<thead>
 								<tr>
 									<th>S/N</th>
 									<th>Level</th>
 									<th>Total Students</th>
 									<th>Academic Session</th>
 								</tr>
 							</thead>
 							<tfoot>
 								<tr>
 									<th>S/N</th>
 									<th>Level</th>
 									<th>Total Students</th>
 									<th>Academic Session</th>
 								</tr>
 							</tfoot>
 						</table>
 					</div>
 				</div>
 			</div>
 		</div>
 	</div>
 </section>

 <?php require_once 'libs/foot.php'; ?>