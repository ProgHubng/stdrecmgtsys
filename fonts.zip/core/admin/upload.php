<?php 
	$page_title = "Upload Result";
	require_once '../core/all.php';
	$id = $_GET['id'];
	if (isset($_POST['ok-add'])){
		$semester = $_POST['semester'];
		$cat_id = $_POST['cat_id'];
		$session = $_POST['session'];
		$status = $_POST['status'];
		$error = array();

		$stmt = $db->prepare("SELECT NULL FROM result WHERE semester =:semester and cat_id =:cat_id and session =:session and  student_id =:student_id");
		$stmt->execute(array('semester'=>$semester,'cat_id'=>$cat_id,'session'=>$session,'student_id'=>$id));

		$rws_count = $stmt->rowCount();

		if ($rws_count >= 1){
			$error[] = 'Invalid result uploading, his/her result has been uploaded';
		}else{
			if (isset($_FILES['upl'])){
				$allwoed = array('pdf');
				$folder = '../image/';
				$files = $_FILES['upl'];
				$name = $files['name'];

				$n = pathinfo($name,PATHINFO_EXTENSION);
				if ($name == ""){
					$error[] = "Upload result is required";
				}else{
					if (!in_array($n, $allwoed)){
						$error[] = "Invalid file upload, it should be only pdf";
					}else{
						if ($files['size'] > 1024 * 1024 * 1){
							$error[] = "Maximum filesize uploading is 1MB";
						}else{
							$tmp = time().'_'.$name;
							$destination = $folder.$tmp;
						}
					}
				}
			}
		}

		$error_count = count($error);
		if ($error_count == 0){
			
			if (move_uploaded_file($_FILES['upl']['tmp_name'], $destination)){
				$in = $db->prepare("INSERT INTO result (student_id,result,session,cat_id,semester,status,add_date)VALUES(:student_id,:result,:session,:cat_id,:semester,:status,:add_date)");
				$in->execute(array('student_id'=>$id,'result'=>$tmp,'session'=>$session,'cat_id'=>$cat_id,'semester'=>$semester,'status'=>$status,'add_date'=>date('d M, Y')));
				set_flash("Result has been uploaded successfully","success");
			}

		}else{
			$msg = "$error_count error(s) occur while uploading student result, try again";
			foreach ($error as $value){
				$msg.='<p>'.$value.'</p>';
			}
			set_flash($msg,'danger');
		}
	}
	require_once 'libs/head.php';
	
 ?>

 <section class="content-wrapper">
 	<div class="content-header">
 		<h3><?php echo $page_title; ?></h3>
 	</div>
 	<div class="content">
 		<div class="row">
 			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
 				<div class="box">
 					<div class="box-header with-border">
 						<h4 class="box-title"><?php echo $page_title; ?></h4>
 					</div>
 					<div class="box-body">
 						<?php flash(); ?>
 						<form class="form-group" method="post" role="form" enctype="multipart/form-data">

 							<div class="form-group">
 								<label>Category </label>
 								<select class="form-control custom-select" name="cat_id" style="height: 48px;">
	 								<option value="1">Regular</option>
									<option value="2">Summer</option>
 								</select>
 							</div>

 							<div class="form-group">
 								<label>Semester</label>
 								<select class="form-control custom-select" style="height: 48px;" name="semester" required="" >
 									<option value="1">First Semester</option>
 									<option value="2">Second Semester</option>
 								</select>
 							</div>

 							<div class="form-group">
 								<label>Academic Session</label>
 								<select class="form-control custom-select" style="height: 48px;" name="session" id="session" required="">
 									<?php 
 										foreach (range(2018, date('Y')) as $value){
 											echo '<option>'.$value.'</option>';
 										}
 									 ?>
 								</select>
 							</div>

 							<div class="form-group">
 								<label>Status</label>
 								<select class="form-control custom-select" name="status" style="height: 48px">
 									<option value="1">Cleared</option>
 									<option value="0">Pending</option>
 								</select>
 							</div>

 							<div class="form-group">
 								<label>Upload Result <span class="text-danger">(only pdf file required)</span></label>
 								<input type="file" name="upl" required="">
 								<small>Maximum filesize upload is 1MB</small>
 							</div>

 							<div class="form-group">
 								<input type="submit" name="ok-add" class="btn btn-primary" value="Upload">
 							</div>
 						</form>
 					</div>
 				</div>
 			</div>
 		</div>
 	</div>
 </section>

 <?php require_once 'libs/foot.php'; ?>