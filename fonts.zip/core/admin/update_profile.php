<?php 
	$page_title = "Update Profile";
	require_once '../core/all.php';
	if (!is_admin_login()){
		header('location:index.php');
		exit();
	}
	if (isset($_POST['ok-update'])){
		$email = $_POST['email'];
		$phone = $_POST['phone'];

		if (strlen($email) > 100){
			set_flash("Invalid email address entered, it must not exceed 100 characters","danger");
		}else{
			if (strlen($phone) != 11 or !is_numeric($phone)){
				set_flash("Invalid phone number format","danger");
			}else{
				$up = $db->prepare("UPDATE admin SET email =:email, phone =:phone WHERE id =:id");
				$up->execute(array('email'=>$email,'phone'=>$phone,'id'=>admin_detail('id')));
				set_flash("Account has been updated successfully","success");
			}
		}
	}
	require_once 'libs/head.php';
	
 ?>

 <section class="content-wrapper">
 	<div class="content-header">
 		<h3><?php echo $page_title; ?></h3>
 	</div>
 	<div class="content">
 		<div class="row">
 			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 ">
 				<div class="box">
 					<div class="box-header with-border">
 						<h5 class="box-title"><?php echo $page_title; ?></h5>
 					</div>
 					<div class="box-body">
 						<?php flash(); ?>
 						<form class="form-group" method="post" role="form">
 							<div class="row">
 								<div class="col-sm-6">
 									<div class="form-group">
 										<label>Username </label>
 										<input type="text" name="username" class="form-control" required="" value="<?php echo admin_detail('username'); ?>" disabled>
 										<small>Please Note : Username can not be changed</small>
 									</div>
 								</div>

 								<div class="col-sm-6">
 									<div class="form-group">
 										<label>Full Name</label>
 										<input type="text" name="fname" class="form-control" required="" disabled="" value="<?php echo admin_detail('fname'); ?>">
 										<small>Please Not: Ful name can not be changed</small>
 									</div>
 								</div>

 								<div class="col-sm-6">
 									<div class="form-group">
 										<label>Email Address</label>
 										<input type="email" name="email" class="form-control" required="" placeholder="Email Address" value="<?php echo admin_detail('email'); ?>">
 									</div>
 								</div>

 								<div class="col-sm-6">
 									<div class="form-group">
 										<label>Phone Number</label>
 										<input type="text" name="phone" class="form-control" required="" placeholder="Phone Number" value="<?php echo admin_detail('phone'); ?>">
 									</div>
 								</div>
 							</div>

 							<div class="form-group">
 								<input type="submit" name="ok-update" class="btn btn-primary" value="Update Profile">
 							</div>
 						</form>
 					</div>
 				</div>
 			</div>
 		</div>
 	</div>
 </section>

 <?php require_once 'libs/foot.php'; ?>