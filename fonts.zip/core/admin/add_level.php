<?php 
	$page_title = "Level";
	require_once '../core/all.php';
	if (!is_admin_login()) {
		header("location:index.php");
		exit();
	}
	if (isset($_POST['ok'])) {
		$name = $_POST['level'];
		$slug = str_replace(" ", "-", $name);

		   $error = array();

		if (strlen($name) >= 10 or strlen($name) < 3) {
			$error[] = "The level should be between 3 - 10, try again";
		}

		$sql = $db->query("SELECT NULL FROM level WHERE name ='$name'");
		$num_row = $sql->rowCount();

		if ($num_row >= 1) {
			$error[] = "The level has already exit, try again";
		}

		$error_count = count($error);
		if ($error_count == 0) {
			
			$in = $db->query("INSERT INTO level (name,slug)VALUES('$name','$slug')");
			set_flash("The level was added successfully","warning");

		}else{
			$msg = "$error_count error(s) occur while add new level try again";
			foreach ($error as $value) {
				$msg.='<p>'.$value.'</p>';
			}
			set_flash($msg,'danger');
		}
	}
	require_once 'libs/head.php';
 ?>

 <section class="content-wrapper">
 	<div class="content-header">
 		<h3><?php echo $page_title; ?></h3>
 	</div>
 	<div class="content">
 		<div class="row">
 			<div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
 				<div class="box">
 					<div class="box-header">
 						<h5 class="box-title">Add <?php echo $page_title; ?></h5>
 					</div>
 					<div class="box-body">
 						
 						<form class="form-group" method="post">
 							<?php flash(); ?>
 							<div class="form-group">
 								<label>Level</label>
 								<input type="text" name="level" class="form-control" required="" placeholder="Level">
 							</div>

 							<div class="form-group">
 								<input type="submit" name="ok" class="btn btn-warning" value="Submit">
 							</div>
 						</form>

 					</div>
 				</div>
 			</div>

 			<div class="col-lg-7 col-md-7 col-sm-12 col-xs-12">
 				<div class="box">
 					<div class="box-header">
 						<h5 class="box-title">All <?php echo $page_title; ?></h5>
 					</div>
 					<div class="box-body">
 						
 						<form class="form-group" method="post">
 							<table class="table text-uppercase table-striped">
 								<thead>
 									<tr>
 										<th>S/N</th>
 										<th></th>
 										<th>Level</th>
 										<th>Actions</th>
 									</tr>
 								</thead>
 								<tfoot>
 									<tr>
 										<th>S/N</th>
 										<th></th>
 										<th>Level</th>
 										<th>Actions</th>
 									</tr>
 								</tfoot>
 								<tbody>
 									<?php 
 										$ii = 1;
 										$sql = $db->query("SELECT * FROM level ORDER BY name");
 										while ($rs = $sql->fetch(PDO::FETCH_ASSOC)) {
 											?>
 											<tr>
 												<td><?php echo $ii++; ?></td>
 												<td><input type="checkbox" name="selecta-all[]" value="<?php echo $rs['id']; ?>"></td>
 												<td><?php echo $rs['name']; ?></td>
 												<td><a href="" class="btn btn-outline-warning"><i class="fa fa-edit"></i> Update</a></td>
 											</tr>
 											<?php
 										}
 									 ?>
 								</tbody>
 							</table>
 						</form>

 					</div>
 				</div>
 			</div>
 		</div>
 	</div>
 </section>

 <?php require_once 'libs/foot.php'; ?>