<?php 
	$page_title ="Update Password";
	require_once '../core/all.php';
	if (!is_admin_login()){
		header('location:index.php');
		exit();
	}
	if (isset($_POST['ok-password-update'])){
		$password = md5($_POST['password']);
		$cpassword = md5($_POST['cpassword']);
		$npassword = md5($_POST['cpassword']);

		$stmt = $db->prepare("SELECT NULL FROM admin WHERE password =:password and id =:id");
		$stmt->execute(array('password'=>$password,'id'=>admin_detail('id')));
		$rs_stmt = $stmt->rowCount();

		if ($rs_stmt == 0){
			set_flash("Invalid old password","danger");
		}else{
			if ($npassword != $cpassword){
				set_flash("Your new password did not match confirm password","danger");
			}else{
				if (strlen($npassword) > 250 or strlen($cpassword) > 250){
					set_flash("Your new password or confirm password is too long","danger");
				}else{
					$up = $db->prepare("UPDATE admin SET password =:p WHERE id =:id");
					$up->execute(array('p'=>$npassword,'id'=>admin_detail('id')));
					set_flash("Your password has been updated successfully","success");
				}
			}
		}
	}
	require_once 'libs/head.php';
	
 ?>

 <section class="content-wrapper">
 	<div class="content-header">
 		<h3><?php echo $page_title; ?></h3>
 	</div>
 	<div class="content">
 		<div class="row">
 			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
 				<div class="box">
 					<div class="box-header with-border">
 						<h5 class="box-title"><?php echo $page_title; ?></h5>
 					</div>
 					<div class="box-body">
 						<?php flash(); ?>
 						<form class="form-group" method="post" role="form">
 							<div class="form-group">
 								<label>Current Password</label>
 								<input type="password" name="password" class="form-control" required="" placeholder="Current Password">
 							</div>

 							<div class="form-group">
 								<label>New Password</label>
 								<input type="password" name="npassword" class="form-control" placeholder="New Password" required="">
 							</div>

 							<div class="form-group">
 								<label>Confirm Password</label>
 								<input type="password" name="cpassword" class="form-control" required="" placeholder="Confirm Password">
 							</div>

 							<div class="form-group">
 								<input type="submit" name="ok-password-update" class="btn btn-primary" value="Update Password">
 							</div>
 						</form>
 					</div>
 				</div>
 			</div>
 		</div>
 	</div>
 </section>

 <?php require_once 'libs/foot.php'; ?>