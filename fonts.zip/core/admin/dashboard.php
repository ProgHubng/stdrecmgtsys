<?php 
	$page_title = "Dashboard";
	require_once '../core/all.php';
	if (!is_admin_login()){
		header('location:index.php');
		exit();
	}
	require_once 'libs/head.php';
 ?>

 <section class="content-wrapper">
 	<div class="content-header">
 		<h3><?php echo $page_title; ?></h3>
 	</div>
 	<div class="content">
 		<div class="row">
 			
 			<?php 
 				$sql = $db->query("SELECT * FROM department ORDER BY name");
 				while ($rs = $sql->fetch(PDO::FETCH_ASSOC)){
 					?>
 					 <div class="col-lg-3 col-xs-6">
				          <!-- small box -->
				          <div class="small-box bg-yellow">
				            <div class="inner">
				              <h3>
				              	<?php 
				              		$dept_id = $rs['id'];
				              		$sqls = $db->query("SELECT * FROM students WHERE dept ='$dept_id'");
				              		echo number_format($sqls->rowCount());
				              	 ?>
				              </h3>

				              <p><?php echo ucwords($rs['name']); ?></p>
				            </div>
				            <div class="icon">
				              <i class="ion ion-bag"></i>
				            </div>
				            <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
				          </div>
				        </div>
 					<?php
 				}
 			 ?>

 		</div>
 	</div>
 </section>

 <?php require_once 'libs/foot.php'; ?>