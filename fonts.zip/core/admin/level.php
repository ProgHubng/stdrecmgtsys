<?php 
	$page_title = "";
	require_once '../core/all.php';
	if (!is_admin_login()){
		header('location:index.php');
		exit();
	}	
	$slugs = $_GET['slugs'];
	$page_title = ucwords(str_replace("-", " ", $slugs));
	
	$slug = $_GET['slug'];
	$stmt = $db->prepare("SELECT * FROM level WHERE slug =:slug");
	$stmt->execute(array('slug'=>$slug));
	$rs = $stmt->fetch(PDO::FETCH_ASSOC);
	$title = strtoupper($rs['name']);

	$level_id = $rs['id'];

	
	$dept_stmt = $db->prepare("SELECT * FROM department WHERE slug =:slug");
	$dept_stmt->execute(array('slug'=>$slugs));
	$rs_dept = $dept_stmt->fetch(PDO::FETCH_ASSOC);

	$dept_id = $rs_dept['id'];

	require_once 'libs/head.php';
	
 ?>

 <section class="content-wrapper">
 	<div class="content-header">
 		<h3><?php echo $page_title; ?></h3>
 	</div>
 	<div class="content">
 		<div class="row">
 			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
 				<div class="box">
 					<div class="box-header with-border">
 						<h5 class="box-title"><?php echo $title; ?></h5>
 					</div>
 					<div class="box-body">
 						<table class="table table-striped table-hover" id="example1">
 							<thead>
 								<tr>
 									<th>S/No</th>
 									<th>Photo</th>
 									<th>Matric Number</th>
 									<th>Full Name</th>
 									<th>Email Address</th>
 									<th>Phone Number</th>
 									<th>Department</th>
 									<th>Level</th>
 									<th>Semester</th>
 									<th>Programme</th>
 									<th>Date</th>
 									<th>Action</th>
 								</tr>
 							</thead>
 							<tfoot>
 								<tr>
 									<th>S/No</th>
 									<th>Photo</th>
 									<th>Matric Number</th>
 									<th>Full Name</th>
 									<th>Email Address</th>
 									<th>Phone Number</th>
 									<th>Department</th>
 									<th>Level</th>
 									<th>Semester</th>
 									<th>Programme</th>
 									<th>Date</th>
 									<th>Action</th>
 								</tr>
 							</tfoot>
 							<tbody>
 								<?php 
 									$ii =1;
 									$stmt = $db->prepare("SELECT * FROM students WHERE dept =:dept and level =:level");
 									$stmt->execute(array('dept'=>$dept_id,'level'=>$level_id));
 									while ($rs = $stmt->fetch(PDO::FETCH_ASSOC)){
 										?>
 										<tr>
 											<td><?php echo $ii++; ?></td>
 											<td><img src="../image/<?php echo $rs['stu_img']; ?>" class="img-circle img-size img-thumbnail"></td>
 											<td><?php echo strtoupper($rs['matric']); ?></td>
 											<td><?php echo ucwords($rs['fname']); ?></td>
 											<td><?php echo $rs['email']; ?></td>
 											<td><?php echo $rs['phone']; ?></td>
 											<td><?php echo department($rs['dept']); ?></td>
 											<td><?php echo strtoupper(level($rs['level'])); ?></td>
 											<td><?php echo semester($rs['semester']); ?></td>
 											<td><?php echo $rs['prog']; ?></td>
 											<td><?php echo $rs['add_date']; ?></td>
 											<td><a href="view.php?id=<?php echo $rs['id']; ?>" class="btn btn-outline-warning">Details</a></td>
 										</tr>
 										<?php
 									}
 								 ?>
 							</tbody>
 						</table>
 					</div>
 				</div>
 			</div>
 		</div>
 	</div>
 </section>

 <?php require_once 'libs/foot.php'; ?>