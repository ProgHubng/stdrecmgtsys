<?php 
	$page_title = "";
	require_once '../core/all.php';
	if (!is_admin_login()){
		header('location:index.php');
		exit();
	}

	$slugs = $_GET['slugs'];
	$page_title = ucwords(str_replace("-", " ", $slugs));
	
	$slug = $_GET['slug'];
	$stmt = $db->prepare("SELECT * FROM level WHERE slug =:slug");
	$stmt->execute(array('slug'=>$slug));
	$rs = $stmt->fetch(PDO::FETCH_ASSOC);
	$level_id = $rs['id'];
	$title = strtoupper($rs['name']);

	
	$dept_stmt = $db->prepare("SELECT * FROM department WHERE slug =:slug");
	$dept_stmt->execute(array('slug'=>$slugs));
	$rs_dept = $dept_stmt->fetch(PDO::FETCH_ASSOC);

	require_once 'libs/head.php';
 ?>

<section class="content-wrapper">
 	<div class="content-header">
 		<h3><?php echo $page_title; ?></h3>
 	</div>
 	<div class="content">
 		<div class="row">

 			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
 				<div class="box">
 					<div class="box-header">
 						<?php echo $title; ?>
 					</div>
 					<div class="box-body">
 						<form method="post">
 							<table class="table table-striped table-hover text-uppercase" id="example1">
	 							<thead>
	 								<tr>
	 									<th>S/N</th>
	 									<th></th>
	 									<th>Course Title</th>
	 									<th>Course Code</th>
	 									<th>Course Unit</th>
	 									<th>Level</th>
	 									<th>Semester</th>
	 									<th>Registered Date</th>
	 									<th>Actions</th>
	 								</tr>
	 							</thead>
	 							<tfoot>
	 								<tr>
	 									<th>S/N</th>
	 									<th></th>
	 									<th>Course Title</th>
	 									<th>Course Code</th>
	 									<th>Course Unit</th>
	 									<th>Level</th>
	 									<th>Semester</th>
	 									<th>Registered Date</th>
	 									<th>Actions</th>
	 								</tr>
	 							</tfoot>
	 							<tbody>
	 								<?php
	 									$dept_id = $rs_dept['id']; 
	 									$ii = 1;
	 									$sql = $db->query("SELECT * FROM course WHERE dept ='$dept_id' and level ='$level_id' ORDER BY course_title DESC");
	 									while ($rs = $sql->fetch(PDO::FETCH_ASSOC)) {
	 										?>
	 										<tr>
	 											<td><?php echo $ii++; ?></td>
	 											<td><input type="checkbox" name="course[]" value="<?php echo $rs['id']; ?>"></td>
	 											<td><?php echo ucwords($rs['course_title']); ?></td>
	 											<td><?php echo $rs['course_code']; ?></td>
	 											<td><?php echo $rs['course_unit']; ?></td>
	 											<td><?php echo ucwords(level($rs['level'])); ?></td>
	 											<td><?php echo semester($rs['semester']); ?></td>
	 											<td><?php echo $rs['add_date']; ?></td>
	 											<td>
	 												<a href="" class="btn btn-warning">Edit Course</a>
	 											</td>
	 										</tr>
	 										<?php
	 									}
	 								 ?>
	 							</tbody>
	 						</table>

	 						<div class="form-group">
                                <input type="submit" name="" class="btn btn-danger" value="Remove">
	 						</div>
 						</form>
 					</div>
 				</div>
 			</div>
	
		</div>
	</div>
</section>

 <?php require_once 'libs/foot.php'; ?>