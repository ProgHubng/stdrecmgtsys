<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 6/15/2018
 * Time: 8:44 PM
 */
//elijah connection  define
require_once 'fun.php';
 
    define('DB_HOST', 'localhost');
    define('DB_TABLE', 'lautechr');
    define('DB_USER', 'root');
    define('DB_PASSWORD', '');
try {
    $db = new PDO('mysql:host='.DB_HOST.';dbname='.DB_TABLE, DB_USER, DB_PASSWORD, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));
    $db->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING );
}
catch (PDOException $e){
    die('<br/><center><font size="15">Could not connect with database</font></center>');
}






































// require_once 'fun.php';
// define('ENV','online');
// date_default_timezone_set("Africa/Lagos");

// if (ENV == "online"){
//     define('DB_HOST', 'localhost');
//     define('DB_TABLE', 'republi1_result');
//     define('DB_USER', 'republi1_result');
//     define('DB_PASSWORD', 'Pass2017WorD');
// }else{
//     define('DB_HOST', 'localhost');
//     define('DB_TABLE', 'app_fpo_result_processing');
//     define('DB_USER', 'root');
//     define('DB_PASSWORD', '');
// }

// try {
//     $db = new PDO('mysql:host='.DB_HOST.';dbname='.DB_TABLE, DB_USER, DB_PASSWORD, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));
//     $db->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING );
// }
// catch (PDOException $e){
//     die('<br/><center><font size="15">Could not connect with database</font></center>');
// }



