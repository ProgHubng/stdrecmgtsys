<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 6/15/2018
 * Time: 8:44 PM
 */
    ob_start();
    session_start();
    function set_flash($msg,$type){
        $_SESSION['flash'] = '<div class="alert alert-'.$type.' alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span></button>'.$msg.'</div>';
    }
    function flash(){
        if (isset($_SESSION['flash'])){
            echo $_SESSION['flash'];
            unset($_SESSION['flash']);
        }
    }
    function is_admin_login(){
        if (isset($_SESSION['admin'])){
            return true;
        }else{
            return false;
        }
    }
    function department($id){
        global $db;
        $stmt = $db->prepare("SELECT id,name FROM department WHERE id =:id");
        $stmt->execute(array('id'=>$id));
        $rs = $stmt->fetch(PDO::FETCH_ASSOC);
        return $rs['name'];
        $stmt->closeCursor();
    }
    function admin_detail($value){
        global $db;
        $stmt = $db->prepare("SELECT * FROM admin WHERE username =:username");
        $stmt->execute(array('username'=>$_SESSION['admin']));
        $rs = $stmt->fetch(PDO::FETCH_ASSOC);
        return $rs[$value];
        $stmt->closeCursor();
    }
    function slug($name){
        $name = str_replace("-", " ", $name);
        return $name;
    }
    function level($id){
         global $db;
        $stmt = $db->prepare("SELECT id,name FROM level WHERE id =:id");
        $stmt->execute(array('id'=>$id));
        $rs = $stmt->fetch(PDO::FETCH_ASSOC);
        return $rs['name'];
        $stmt->closeCursor();
    }
    function semester($n){
        if ($n == 1){
            return "First Semester";
        }else{
            return "Second Semester";
        }
    }
    function result_category($j){
        if ($j == 1){
            return "Regular";
        }else{
            return "Summer";
        }
    }
    function status($j){
        if ($j == 0){
            return "Inactive";
        }else{
            return "Active";
        }
    }

    function course ($id,$value){
        global $db;
        $sql = $db->query("SELECT * FROM course WHERE id ='$id'");
        $rs = $sql->fetch(PDO::FETCH_ASSOC);
        return $rs[$value];
    }

    function staff_details($id,$value){
        global $db;
        $sql = $db->query("SELECT * FROM admin WHERE id ='$id'");
        $rs = $sql->fetch(PDO::FETCH_ASSOC);
        return $rs[$value];
    }

    function grade($scores){
        if ($scores >= 75 || $$scores >= 100){
            return "4.00";
        } else if ($scores >= 70 || $scores >= 74 ){
            return "3.50";
        } else if ($scores >= 65 || $scores >= 69){
            return "3.25";
        }else if ($scores >= 60 || $scores >= 64){
            return "3.00";
        } else if ($scores >= 55 || $scores >= 59){
            return "2.75";
        } else if ($scores >= 50 || $scores >= 54){
            return "2.50";
        } else if ($scores >= 45 || $scores >= 49){
            return "2.25";
        } else if ($scores >= 40 || $scores >= 44){
            return "2.00";
        } else {
            return "0.00";
        }
    }

function gpa_point($point) {
    if ($point >= "3.50" || $point >= "4.00"){
        return "Distinction";
    } else if ($point >= "3.00" || $point >= "3.49"){
        return "Upper Credit";
    } else if ($point >= "2.50" || $point >= "2.99"){
        return  "Lower Credit";
    } else{
        return  "Passed";
    }
}


 function grades($scores){
        if ($scores >= 75 || $$scores >= 100){
            return "A";
        } else if ($scores >= 70 || $scores >= 74 ){
            return "AB";
        } else if ($scores >= 65 || $scores >= 69){
            return "B";
        }else if ($scores >= 60 || $scores >= 64){
            return "BC";
        } else if ($scores >= 55 || $scores >= 59){
            return "C";
        } else if ($scores >= 50 || $scores >= 54){
            return "CD";
        } else if ($scores >= 45 || $scores >= 49){
            return "D";
        } else if ($scores >= 40 || $scores >= 44){
            return "E";
        } else {
            return "F";
        }
    }