<?php
    require_once '../db/db.php';
    $page_title = "Semester Result uploading";
require_once 'libs/head.php';
require_once 'libs/menu.php';
?>
<section class="content-wrapper">
    <div class="content-header">
        <h1><?php echo $page_title; ?></h1>
        <ol class="breadcrumb">
            <li><a href="tmp.php">Student cPanel</a></li>
            <li class="active"><?php echo $page_title; ?></li>
        </ol>
    </div>
    <div class="content">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="box box-danger">
                    <div class="box-header">
                        <h5 class="box-title"><?php echo $page_title; ?></h5>
                    </div>
                    <div class="box-body">
                        <?php flash(); ?>
                        <form class="form-group" method="post" role="form">
                            <table class="table table-bordered table-striped table-hover" style="font-weight: bold; cursor: pointer;">
                                <tr>
                                    <td>SN</td>
                                    <td>Course Title</td>
                                    <td>Course Code</td>
                                    <td>Unit</td>
                                    <td>Score</td>
<!--                                    <td>Grade</td>-->
                                </tr>
                                <?php
                                if(student_detail('semester') == 1 and student_detail('level') == 'ND 1 FT')
                                {
                                    $stmt = $db->prepare("SELECT * FROM course WHERE semester=:semester and level=:level ORDER BY course_code ");
                                    $stmt->execute(array('semester' => 1, 'level' => 1));
                                    $r.="<select name='course_title'>";
                                    while($rs = $stmt->fetch())
                                    {
                                        //var_dump($rs );
                                        
                                           
                                            $r.="<option value=''>{$rs['course_title']}</option>";
                                            }
                                            $r.="</select>";
                                        ?>
                                        <tr>
                                            <td><input type="checkbox" name="course[]" value="<?php echo $rs['id']; ?>"></td>
<!--                                            <td><select name="course[]" id="">-->

<!--                                                    <option value="--><?php //echo ucwords($rs['course_title']); ?><!--"> </option></select></td>-->
<!--                                            <td><select name="" id="">-->
<!--                                                    <option value="--><?php //echo ucfirst($rs['course_code']); ?><!--"></option></select></td>-->
<!--                                            <td><select name="" id="">-->
<!--                                                    <option value="--><?php //echo $rs['unit']; ?><!--"></option></select></td>-->

//                                                     ?><!--</option></select>   </td>-->
<!--                                            <td><input type="text"> </td>-->

                                            <td><select name="" id="">
                                                    <option value=" $rs['course_title'] "><?php echo $rs['course_title']?></option></select>
                                            </td>
                                            <td><select name="course[]" id="">
                                                  <option value=""><?php echo ucwords($rs['course_code']); ?> </option></select>
                                            </td>
                                            <td><select name="course[]" id="">
                                                    <option value=""><?php echo ucwords($rs['unit']); ?> </option></select>
                                            </td>
                                            <td><input type="text">
                                            </td>

                                        </tr>

                                        <?php
//                                        var_dump($rs['id']);
                                    }
                                else{
                                    if (student_detail('semester') == 2 and student_detail('level') == 'ND 1 FT')
                                    {
                                        $stmt = $db->prepare("SELECT * FROM course WHERE semester=:semester and level=:level ORDER BY course_title");
                                        $stmt->execute(array('semester' => 2, 'level' => 1));
                                        while ($rs = $stmt->fetch())
                                        {
                                            ?>
                                            <tr>
                                                <td><input type="checkbox" name="course[]" value="<?php echo $rs['id']; ?>"></td>
                                                <td><?php echo strtoupper($rs['course_title']); ?></td>
                                                <td><?php echo strtoupper($rs['course_code']); ?></td>
                                                <td><?php echo $rs['unit']; ?></td>
                                            </tr>
                                            <?php
                                        }
                                    }else{
                                        if (student_detail('semester') == 1 and student_detail('level') == 'ND 2 FT')
                                        {
                                            $stmt = $db->prepare("SELECT * FROM course WHERE semester=:semester and level=:level ORDER BY course_title");
                                            $stmt->execute(array('semester' => 1, 'level' => 2));
                                            while ($rs = $stmt->fetch())
                                            {
                                                ?>
                                                <tr>
                                                    <td><input type="checkbox" name="course[]" value="<?php echo $rs['id']; ?>"></td>
                                                    <td><?php echo strtoupper($rs['course_title']); ?></td>
                                                    <td><?php echo strtoupper($rs['course_code']); ?></td>
                                                    <td><?php echo $rs['unit']; ?></td>
                                                    <td><input type="text" name="grade"></td>
                                                </tr>
                                                <?php
//                                                var_dump($rs['id']);
//                                                var_dump($rs['course_title']);
                                            }
                                        }else{
                                            if (student_detail('semester') == 2 and student_detail('level') == 'ND 2 FT') {
                                                $stmt = $db->prepare("SELECT * FROM course WHERE semester=:semester and level=:level ORDER BY course_title");
                                                $stmt->execute(array('semester' => 2, 'level' => 2));
                                                while ($rs = $stmt->fetch())
                                                {
                                                    ?>
                                                    <tr>
                                                        <td><input type="checkbox" name="course[]" value="<?php echo $rs['id']; ?>"></td>
                                                        <td><?php echo strtoupper($rs['course_title']); ?></td>
                                                        <td><?php echo strtoupper($rs['course_code']); ?></td>
                                                        <td><?php echo $rs['unit']; ?></td>
                                                    </tr>
                                                    <?php
                                                }
                                            }
                                        }
                                    }
                                }
//                                $stmt->closeCursor();
                                ?>
                            </table>

                            <input type="submit" name="ok-add" class="btn btn-info" value="Upload Result">
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<?php require_once "../libs/foot1.php"?>
