<?php
$page_title = "First Semester Result";
//$page_title1=""
require_once '../db/db.php';
if (!admin())
{
    header('location:login.php');
    exit();
}
// if (isset($_POST['ok']))
// {
//     $level = $_POST['level'];
//     $semester = $_POST['semester'];
//     if (isset($_GET['id']))
//     {
//         $stmt = $db->prepare("UPDATE students SET level =:level, semester =:semester WHERE id =:id");
//         $stmt->execute(array('level' => $level,'semester' => $semester,'id' => $_GET['id']));
//         set_flash('student profile has been update successfully','info');
//     }
// }
require_once 'libs/head.php';
require_once 'libs/menu.php';
?>
<section class="content-wrapper">
    <div class="content-header">
        <h3><?php echo $page_title ?> </h3>
        <lo class="breadcrumb">
            <li> <a href="dashboard.php">Dashboard</a> </li>
            <li class="active"><?php echo $page_title ?> </li>
       </lo>
    </div>
    <div class="content">
      <div class="row">
         <div class="col-md-12 col-sm-12 col-xm-12">
            <div class="box box-danger">
               <div class="box-header">
                  <div class="box-title"> <h5 class="page-header"> Student Result uploading</h5></div>
                     <form action="" class=" form-group " method="">
                        <div class="col-sm-3">
                  <div class="form-group">
                    <label class=""> ACADAMICS SESSION</label>
                    <select class="custom-select form-control-select form-control" name="month" required="">
                        <?php 
                          $a = array("SESSION 2018/2019","SESSION 2019/2020");
                          foreach ($a as  $value) 
                          {
                            echo '<option>'.$value.'</option>';
                          }
                         ?>
                    </select>
                  </div>
                </div>
                          <div class="col-md-3 col-sm-6 col-xm-12">

                           <label> Department</label>

                           <select name="" id="" class="form-control form-control-select custom-select">

                             <option> Select Department</option>
                            <?php flash(); ?>
                             <?php 
                                
               if(isset($_GET['dept_name'])) 
              {
                $stmt = $db->prepare("SELECT * FROM dept WHERE dept_name =:dept_name");
                $stmt->execute(array('dept_name' => $_GET['id']));
                while ($n = $stmt->fetch()) 
                {
                  ?>
                                 
                                
                                    <option><?php echo $n['dept']; ?> </option>
                              
                            
                          </select>
                          </div>
                           
                        </form>




                    </div>
<?php        
                           }
                           var_dump($n);
                         $stmt->closeCursor();  
                       }
                          ?>
                </div>

            </div>
        </div>

    </div>

</section>




<?php require_once 'libs/foot.php';?>